Renderer.CanvasModels["LJmain"] = {
	name: "LJmain",
	width: 256,
	height: 256,
	frames: 2,
	generatedOptions() {
		return [
			"blink_animation",
			"genitals_chastity",
			"handheld_position",
			"handheld_overhead",
			"zarms",
			...setup.clothes_all_slots.flatMap(key => [
				"worn_" + key + "_setup"
			])
		]
	},
	defaultOptions() {
		return {
			// group toggles
			"show_face": true,
			"show_hair": true,
			"show_tanlines": true,
			"show_writings": true,
			"show_tf": true,
			"show_clothes": true,
			// body
			"mannequin": false,
			"breasts": "",
			"breast_size": 1,
			"crotch_visible": false,
			"crotch_exposed": false,
			"penis": "",
			"penis_size": -1,
			"penis_parasite": "",
			"penis_condom": "",
			"condom_colour": "",
			"balls": false,
			"nipples_parasite": "",
			"chest_parasite": "",
			"clit_parasite": "",
			"arm_left": "idle",
			"arm_right": "idle",
			"body_type": "m",
			// Skin & tan
			"skin_type": "light",
			"skin_tone": 0,
			"skin_tone_breasts": -0.01,
			"skin_tone_penis": -0.01,
			"skin_tone_swimshorts": -0.01,
			"skin_tone_swimsuitTop": -0.01,
			"skin_tone_swimsuitBottom": -0.01,
			"skin_tone_bikiniTop": -0.01,
			"skin_tone_bikiniBottom": -0.01,
			// Hair
			"hair_colour": "red",
			"hair_colour_gradient": {
				style: "split",
				colours: ["red", "black"]
			},
			"hair_colour_style": "simple",
			"hair_sides_type": "default",
			"hair_sides_length": "short",
			"hair_sides_position": "back",
			"hair_fringe_colour": "red",
			"hair_fringe_colour_gradient": {
				style: "split",
				colours: ["red", "black"]
			},
			"hair_fringe_colour_style": "simple",
			"hair_fringe_type": "default",
			"hair_fringe_length": "short",
			"brows_colour": "",
			"brows_position": "front",
			"pbhair_colour": "",
			"pbhair_level": 0,
			"pbhair_strip": 0,
			"pbhair_balls": 0,
			// Face
			"facestyle": "default",
			"ears_position": "back",
			"freckles": false,
			"trauma": false,
			"blink": true,
			"eyes_half": false,
			"eyes_bloodshot": false,
			"left_eye": "purple",
			"right_eye": "purple",
			"brows": "none",
			"mouth": "none",
			"tears": 0,
			"blush": 0,
			"toast": 0,
			"lipstick_colour": "",
			"eyeshadow_colour": "",
			"mascara_colour": "",
			"mascara_running": 0,
			// tf
			"angel_wings_type": "disabled",
			"angel_wing_right": "idle",
			"angel_wing_left": "idle",
			"angel_wings_layer": "front",
			"angel_halo_type": "disabled",
			"angel_halo_lower": false,
			"fallen_wings_type": "disabled",
			"fallen_wing_right": "idle",
			"fallen_wing_left": "idle",
			"fallen_wings_layer": "front",
			"fallen_halo_type": "disabled",
			"demon_wings_type": "disabled",
			"demon_wings_state": "idle",
			"demon_wings_layer": "front",
			"demon_tail_type": "disabled",
			"demon_tail_state": "idle",
			"demon_tail_layer": "front",
			"demon_horns_type": "disabled",
			"demon_horns_layer": "back",
			"wolf_tail_type": "disabled",
			"wolf_tail_layer": "front",
			"wolf_ears_type": "disabled",
			"wolf_pits_type": "disabled",
			"wolf_pubes_type": "disabled",
			"wolf_cheeks_type": "disabled",
			"cat_tail_type": "disabled",
			"cat_tail_state": "idle",
			"cat_tail_layer": "front",
			"cat_ears_type": "disabled",
			"cow_horns_type": "disabled",
			"cow_horns_layer": "back",
			"cow_tail_type": "disabled",
			"cow_tail_layer": "front",
			"cow_ears_type": "disabled",
			"bird_wings_type": "disabled",
			"bird_wing_right": "idle",
			"bird_wing_left": "idle",
			"bird_wings_layer": "front",
			"bird_tail_type": "disabled",
			"bird_tail_layer": "front",
			"bird_eyes_type": "disabled",
			"bird_malar_type": "disabled",
			"bird_plumage_type": "disabled",
			"bird_pubes_type": "disabled",
			"fox_tail_type": "disabled",
			"fox_tail_layer": "front",
			"fox_ears_type": "disabled",
			"fox_cheeks_type": "disabled",
			// body writings
			"writing_forehead": "",
			"writing_left_cheek": "",
			"writing_right_cheek": "",
			"writing_breasts": "",
			"writing_left_shoulder": "",
			"writing_right_shoulder": "",
			"writing_pubic": "",
			"writing_left_thigh": "",
			"writing_right_thigh": "",
			// fluids
			"drip_vaginal": "",
			"drip_anal": "",
			"drip_mouth": "",
			"cum_chest": "",
			"cum_face": "",
			"cum_feet": "",
			"cum_leftarm": "",
			"cum_rightarm": "",
			"cum_neck": "",
			"cum_thigh": "",
			"cum_tummy": "",
			// clothing
			"worn_upper": 0,
			"worn_upper_alpha": 1,
			"worn_upper_integrity": "full",
			"worn_upper_colour": "white",
			"worn_upper_acc_colour": "white",
			"worn_upper_setup": { type: [] }, // generated option
			"worn_over_upper": 0,
			"worn_over_upper_alpha": 1,
			"worn_over_upper_integrity": "full",
			"worn_over_upper_colour": "white",
			"worn_over_upper_acc_colour": "white",
			"worn_over_upper_setup": { type: [] }, // generated option
			"worn_genitals": 0,
			"worn_genitals_alpha": 1,
			"worn_genitals_integrity": "full",
			"worn_genitals_colour": "white",
			"worn_genitals_acc_colour": "white",
			"worn_genitals_setup": { type: [] }, // generated option
			"worn_lower": 0,
			"worn_lower_alpha": 1,
			"worn_lower_integrity": "full",
			"worn_lower_colour": "white",
			"worn_lower_acc_colour": "white",
			"worn_lower_setup": { type: [] }, // generated option
			"worn_over_lower": 0,
			"worn_over_lower_alpha": 1,
			"worn_over_lower_integrity": "full",
			"worn_over_lower_colour": "white",
			"worn_over_lower_acc_colour": "white",
			"worn_over_lower_setup": { type: [] }, // generated option
			"worn_under_lower": 0,
			"worn_under_lower_alpha": 1,
			"worn_under_lower_integrity": "full",
			"worn_under_lower_colour": "white",
			"worn_under_lower_acc_colour": "white",
			"worn_under_lower_setup": { type: [] }, // generated option
			"worn_under_upper": 0,
			"worn_under_upper_alpha": 1,
			"worn_under_upper_integrity": "full",
			"worn_under_upper_colour": "white",
			"worn_under_upper_acc_colour": "white",
			"worn_under_upper_setup": { type: [] }, // generated option
			"worn_hands": 0,
			"worn_hands_alpha": 1,
			"worn_hands_integrity": "full",
			"worn_hands_colour": "white",
			"worn_hands_acc_colour": "white",
			"worn_hands_setup": { type: [] }, // generated option
			"worn_handheld": 0,
			"worn_handheld_alpha": 1,
			"worn_handheld_integrity": "full",
			"worn_handheld_colour": "white",
			"worn_handheld_acc_colour": "white",
			"worn_handheld_setup": { type: [] }, // generated option
			"worn_head": 0,
			"worn_head_alpha": 1,
			"worn_head_integrity": "full",
			"worn_head_colour": "white",
			"worn_head_acc_colour": "white",
			"worn_head_setup": { type: [] }, // generated option
			"worn_over_head": 0,
			"worn_over_head_alpha": 1,
			"worn_over_head_integrity": "full",
			"worn_over_head_colour": "white",
			"worn_over_head_acc_colour": "white",
			"worn_over_head_setup": { type: [] }, // generated option
			"worn_face": 0,
			"worn_face_alpha": 1,
			"worn_face_integrity": "full",
			"worn_face_colour": "white",
			"worn_face_acc_colour": "white",
			"worn_face_setup": { type: [] }, // generated option
			"worn_neck": 0,
			"worn_neck_alpha": 1,
			"worn_neck_integrity": "full",
			"worn_neck_colour": "white",
			"worn_neck_acc_colour": "white",
			"worn_neck_setup": { type: [] }, // generated option
			"worn_legs": 0,
			"worn_legs_alpha": 1,
			"worn_legs_integrity": "full",
			"worn_legs_colour": "white",
			"worn_legs_acc_colour": "white",
			"worn_legs_setup": { type: [] }, // generated option
			"worn_feet": 0,
			"worn_feet_alpha": 1,
			"worn_feet_integrity": "full",
			"worn_feet_colour": "white",
			"worn_feet_acc_colour": "white",
			"worn_feet_setup": { type: [] }, // generated option
			// misc
			"genitals_chastity": false, // generated option
			"handheld_overhead": false, // generated option
			"upper_tucked": false,
			"lower_tucked": false,
			"hood_down": false,
			"alt_position": false,
			"alt_sleeve": false,
			"alt_position_neck":false,
			"alt_position_face":false,
			"acc_layer_under": false,
			"head_mask_src": "", // generated option
			"belly_mask_src": "", // generated option
			"blink_animation": "", // generated option
			"ztan_swimshorts": ZIndices.base, // generated option
			"ztan_swimsuitTop": ZIndices.base, // generated option
			"ztan_swimsuitBottom": ZIndices.base, // generated option
			"ztan_bikiniTop": ZIndices.breasts, // generated option
			"ztan_bikiniBottom": ZIndices.base, // generated option
			"zarms": ZIndices.armsidle, // generated options
			"zupper": ZIndices.upper, // generated options
			"zupperleft": ZIndices.upper_arms, // generated options
			"zupperright": ZIndices.upper_arms, // generated options
			// filters
			"LJ_zRarmup": ZIndices.upper_arms,// 新增属性
			"filters": {}
		}
	},
	preprocess(options) {
		options.blink_animation = options.blink ? options.trauma ? "blink-trauma" : "blink" : "";

		// Generate skin tone & tanlines filters
		if (options.skin_type !== "custom") {
			options.filters.body = setup.colours.getSkinFilter(options.skin_type, options.skin_tone);
			options.filters.breasts = options.filters.body
			options.filters.penis = options.filters.body
			if (options.show_tanlines) {
				let tanslots = [
					'breasts', 'penis',
					'swimshorts',
					'swimsuitTop', 'swimsuitBottom',
					'bikiniTop', 'bikiniBottom'
				].map(slotname => [slotname, options['skin_tone_' + slotname]]).
					filter(slot => slot[1] >= 0); // [slotname, tanvalue], only for tanvalue >= 0
				// Brightest on top
				tanslots.sort((a, b) => b[1] - a[1]);
				tanslots.forEach((slot, i) => {
					options.filters[slot[0]] = setup.colours.getSkinFilter(options.skin_type, slot[1]);
					options['ztan_' + slot[0]] = options['ztan_' + slot[0]] + 0.01 * i;
				});
			}
		}
		// Generate filters for colour-by-name properties
		/**
		 * For colour name, lookup its canvas filter and merge with sprite prefilter.
		 * @param key colour name
		 * @param dict map in setup.colours to lookup in
		 * @param debugName used when reporting errors
		 * @param customFilterName key in options.filters
		 * @param prefilterName name of prefilter to apply
		 * @return {CompositeLayerParams}
		 */

		function lookupColour(dict, key, debugName, customFilterName, prefilterName) {
			let filter;
			if (key === "custom") {
				filter = clone(options.filters[customFilterName]);
				if (!filter) {
					console.error("custom " + debugName + " colour not configured");
					return {};
				}
			} else if (key !== "original") {
				let record = dict[key];
				if (!record) {
					console.error("unknown " + debugName + " colour: " + key);
					return {};
				}
				filter = clone(record.canvasfilter);
			}

			if (prefilterName) {
				Renderer.mergeLayerData(filter,
					setup.colours.sprite_prefilters[prefilterName],
					true
				);
			}
			return filter;
		}

		function createHairColourGradient(hairPart, gradient, hairType, hairLength, prefilterName) {
			const filterPrototypeLibrary = setup.colours.hairgradients_prototypes[hairPart][gradient.style];
			const filterPrototype = filterPrototypeLibrary[hairType] || filterPrototypeLibrary.all;
			const filter = {
				blend: clone(filterPrototype),
				brightness: {
					gradient: filterPrototype.gradient,
					values: filterPrototype.values,
					adjustments: [[], []]
				},
				blendMode: "hard-light"
			};
			for (const colorIndex in filter.blend.colors) {
				filter.brightness.adjustments[colorIndex][0] = filter.blend.lengthFunctions[0](hairLength, filter.blend.colors[colorIndex][0]);
				filter.brightness.adjustments[colorIndex][1] = setup.colours.hair_map[gradient.colours[colorIndex]].canvasfilter.brightness || 0;

				filter.blend.colors[colorIndex][0] = filter.blend.lengthFunctions[0](hairLength, filter.blend.colors[colorIndex][0]);
				filter.blend.colors[colorIndex][1] = setup.colours.hair_map[gradient.colours[colorIndex]].canvasfilter.blend;
			}
			Renderer.mergeLayerData(filter, setup.colours.sprite_prefilters[prefilterName], true);

			return filter;
		}

		options.filters.left_eye = lookupColour(setup.colours.eyes_map, options.left_eye, "eyes", "eyes_custom", "eyes");
		options.filters.right_eye = lookupColour(setup.colours.eyes_map, options.right_eye, "eyes", "eyes_custom", "eyes");
		if (options.hair_colour_style === "gradient") {
			options.filters.hair = createHairColourGradient(
				"sides",
				options.hair_colour_gradient,
				options.hair_sides_type,
				hairLengthStringToNumber(options.hair_sides_length),
				"hair"
			);
		}
		if (options.hair_colour_style === "simple") {
			options.filters.hair = lookupColour(
				setup.colours.hair_map,
				options.hair_colour,
				"hair",
				"hair_custom",
				"hair"
			);
		}
		if (options.hair_fringe_colour_style === "gradient") {
			options.filters.hair_fringe = createHairColourGradient(
				"fringe",
				options.hair_fringe_colour_gradient || options.hair_colour_gradient,
				options.hair_fringe_type,
				hairLengthStringToNumber(options.hair_sides_length),
				"hair_fringe"
			);
		}
		if (options.hair_fringe_colour_style === "simple") {
			options.filters.hair_fringe = lookupColour(
				setup.colours.hair_map,
				options.hair_fringe_colour || options.hair_colour,
				"hair_fringe",
				"hair_fringe_custom",
				"hair_fringe"
			);
		}
		options.filters.brows = lookupColour(setup.colours.hair_map, options.brows_colour || options.hair_colour, "brows", "brows_custom", "brows");
		options.filters.pbhair = lookupColour(setup.colours.hair_map, options.pbhair_colour || options.hair_colour, "pbhair", "pbhair_custom", "pbhair");
		if (options.lipstick_colour) {
			options.filters.lipstick = lookupColour(setup.colours.lipstick_map, options.lipstick_colour, "lipstick", "lipstick_custom", "lipstick");
		} else {
			options.filters.lipstick = Renderer.emptyLayerFilter();
		}
		if (options.eyeshadow_colour) {
			options.filters.eyeshadow = lookupColour(setup.colours.eyeshadow_map, options.eyeshadow_colour, "eyeshadow", "eyeshadow_custom", "eyeshadow");
		} else {
			options.filters.eyeshadow = Renderer.emptyLayerFilter();
		}
		if (options.mascara_colour) {
			options.filters.mascara = lookupColour(setup.colours.mascara_map, options.mascara_colour, "mascara", "mascara_custom", "mascara");
		} else {
			options.filters.mascara = Renderer.emptyLayerFilter();
		}
		if (options.condom_colour) options.filters.condom = lookupColour(setup.colours.condom_map, options.condom_colour, "condom", "condom_custom", "condom");

		if (options.breasts_parasite === "parasite") {
			options.filters.breasts_parasite = lookupColour(setup.colours.clothes_map, "red", "breasts_parasite");
		}
		if (["parasite", "parasitem"].includes(options.clit_parasite)) {
			options.filters.clit_parasite = lookupColour(setup.colours.clothes_map, "red", "clit_parasite");
		}
		if (options.penis_parasite === "parasite") {
			options.filters.penis_parasite = lookupColour(setup.colours.clothes_map, "red", "penis_parasite");
		}

		// Clothing filters and options
		for (let slot of setup.clothes_all_slots) {
			let index = options["worn_" + slot];
			if (index > 0) {
				/**
				 * @type {ClothesItem}
				 */
				let setupobj = setup.clothes[slot][index];
				options["worn_" + slot + "_setup"] = setupobj;

				if (setupobj.colour_sidebar) {
					options.filters["worn_" + slot] = lookupColour(
						setup.colours.clothes_map,
						options["worn_" + slot + "_colour"],
						slot + " clothing",
						"worn_" + slot + "_custom",
						setupobj.prefilter
					);
				} else {
					options.filters["worn_" + slot] = Renderer.emptyLayerFilter();
				}

				if (setupobj.accessory_colour_sidebar) {
					options.filters["worn_" + slot + "_acc"] = lookupColour(
						setup.colours.clothes_map,
						options["worn_" + slot + "_acc_colour"],
						slot + " accessory",
						"worn_" + slot + "_acc_custom",
						setupobj.prefilter
					);
				} else {
					options.filters["worn_" + slot + "_acc"] = Renderer.emptyLayerFilter();
				}
			}
		}

		// Show arm and hand just below outermost clothes layer to fully show its main/breasts layer and hide others
		// -0.1 is to move arms behind sleeves; to display gloves above sleeves they get +0.2 in hand layer decls
		if (options.worn_over_upper) {
			options.zarms = ZIndices.over_upper_arms - 0.1;
		} else if (options.worn_upper) {
			if (options.arm_left === "cover") {
				if (options.upper_tucked) {
					options.zarms = ZIndices.upper_arms_tucked - 0.1;
				} else {
					options.zarms = ZIndices.upper_arms - 0.1;
				}
			} else {
				options.zarms = ZIndices.under_upper_arms - 0.1;
			}
		} else if (options.worn_under_upper) {
			options.zarms = ZIndices.under_upper_arms - 0.1;
		} else {
			options.zarms = ZIndices.armsidle
		}
		// Do not put skin above sleeves
		if (options.worn_under_upper_setup.sleeve_img === 1) {
			options.zarms = ZIndices.under_upper_arms - 0.1;
		} else if (options.worn_upper_setup.sleeve_img === 1) {
			if (options.arm_left === "cover") {
				if (options.upper_tucked) {
					options.zarms = ZIndices.upper_arms_tucked - 0.1;
				} else {
					options.zarms = ZIndices.upper_arms - 0.1;
				}
			} else {
				options.zarms = ZIndices.under_upper_arms - 0.1;
			}
		}

		options.LJ_zRarmup = (options.worn_upper_setup.LJ_Rarmup || options.worn_under_upper_setup.LJ_Rarmup || options.worn_over_upper_setup.LJ_Rarmup )//改动：判定是否有衣服的袖子前置

		if (options.upper_tucked) {
			options.zupper = ZIndices.upper_tucked;
			options.zupperleft = ZIndices.upper_arms_tucked;
			options.zupperright = ZIndices.upper_arms_tucked;
		} else {
			options.zupper = ZIndices.upper;
			options.zupperleft = ZIndices.upper_arms;
			options.zupperright = ZIndices.upper_arms;
		}
		options.zupperright = (options.arm_right === "bound"  || (options.arm_right === "idle" && !options.LJ_zRarmup )) ?  (ZIndices.base - 1) : ZIndices.upper_arms_cover;//改动：上衣手臂前置
		options.zupperleft =  (options.arm_left === "bound"  || options.arm_left === "idle") ? (ZIndices.base - 1) : ZIndices.upper_arms_cover ;

		// Generate mask images
		if (options.worn_upper_setup.mask_img === 1 && options.worn_upper_setup.name === "cocoon") {
			options.head_mask_src = "img/clothes/upper/cocoon/mask.png";
		} else if (options.worn_over_head_setup.mask_img === 1 &&
			!(options.hood_down && options.worn_over_head_setup.hood && options.worn_over_head_setup.outfitSecondary !== undefined)) {
			options.head_mask_src = "img/clothes/head/" + options.worn_over_head_setup.variable + "/mask.png";
		} else if (options.worn_head_setup.mask_img === 1 &&
			!(options.hood_down && options.worn_head_setup.hood && options.worn_head_setup.outfitSecondary !== undefined)) {
			if (options.worn_head_setup.mask_img_ponytail === 1 && ["curly pigtails", "fluffy ponytail", "thick sidetail", "thick twintails", "ribbon tail", "thick sidetail", "thick ponytail", "half-up"].includes(options.hair_sides_type) || ["scorpion tails", "thick pigtails", "thick twintails"].includes(options.hair_sides_type) && ["furcap f", "furcap m"].includes(options.worn_head_setup.variable)) {
				options.head_mask_src = "img/clothes/head/" + options.worn_head_setup.variable + "/mask_ponytail.png";
			} else {
				options.head_mask_src = "img/clothes/head/" + options.worn_head_setup.variable + "/mask.png";
			}
		} else {
			options.head_mask_src = null;
		}

		if (["fro", "afro pouf", "afro puffs"].includes(options.hair_sides_type) && ["fro"].includes(options.hair_fringe_type)) {
			options.fringe_mask_src = "img/hair/fringe/" + options.hair_fringe_type + "/mask.png";
		} else {
			options.fringe_mask_src = null;
		}

		if ((options.worn_upper_setup.type.includes("bellyHide")) || (options.worn_lower_setup.type.includes("bellyHide")) || !(V.worn.over_upper.type.includes("naked"))) {
			options.belly -= 3;
		}
		if (between(options.belly, 8, 24)) {
			options.belly_mask_lower_shadow_src = "img/clothes/belly/shadow_" + options.belly + ".png";
			options.belly_mask_upper_shadow_src = "img/clothes/belly/shadow_" + options.belly + ".png";
		}
		if (between(options.belly, 15, 24)) {
			if (options.worn_upper_setup.pregType == "min") {
				options.belly_mask_src = "img/clothes/belly/mask_min_" + options.belly + ".png";
			} else {
				options.belly_mask_src = "img/clothes/belly/mask_" + options.belly + ".png";
			}
			if (V.worn.upper.outfitPrimary == undefined && options.worn_lower_setup.pregType != "cover") {
				if (options.belly >= 19) {
					options.belly_hides_lower = true;
					options.belly_mask_clip_src = "img/clothes/belly/mask_clip_" + options.belly + ".png";
					if (options.worn_upper_setup.pregType == "split") {
						options.shirt_mask_clip_src = "img/clothes/belly/mask_shirt_clip" + (options.belly >= 22 ? "_big.png" : ".png");
						options.shirt_move_left_src = "img/clothes/belly/mask_shirt_left" + (options.belly >= 22 ? "_big.png" : ".png");
						options.shirt_move_left2_src = "img/clothes/belly/mask_shirt_left2.png";
						options.shirt_mask_breasts_src = "img/clothes/belly/mask_shirt_breasts.png";
						options.shirt_move_right_src = "img/clothes/belly/mask_shirt_right.png";
						options.shirt_move_right2_src = "img/clothes/belly/mask_shirt_right2.png";
						options.shirt_move_right3_src = "img/clothes/belly/mask_shirt_right3.png";
					} else {
						options.shirt_mask_clip_src = null;
						options.shirt_move_left_src = null;
						options.shirt_move_left2_src = null;
						options.shirt_move_right_src = null;
						options.shirt_move_right2_src = null;
						options.shirt_move_right3_src = null;
					}
				} else {
					options.belly_mask_clip_src = null;
				}
			}
			if (V.worn.under_upper.outfitPrimary == undefined) {
				options.belly_hides_under_lower = true;
				options.belly_mask_under_clip_src = "img/clothes/belly/mask_clip_" + options.belly + ".png";
			} else {
				options.belly_mask_under_clip_src = null;
			}
		}
		if (["f", "a"].includes(options.body_type) && options.breasts === "cleavage") {
			if ([3, 4].includes(options.breast_size)) {
				options.breasts_mask_src = `img/body/breasts/breasts-${options.body_type}-mid.png`;
			} else {
				options.breasts_mask_src = `img/body/breasts/breasts-${options.body_type}.png`;
			}
		} else {
			options.breasts_mask_src = null;
		}
		if (["f", "a"].includes(options.body_type)) {
			if (options.worn_upper_setup.formfitting || options.worn_under_upper_setup.formfitting) {
				options.shirt_fitted_clip_src = `img/clothes/masks/formfitting_${options.body_type}.png`;
				options.shirt_fitted_right_move_src = `img/clothes/masks/formfitting_right_move.png`;
				options.shirt_fitted_left_move_src = `img/clothes/masks/formfitting_left_move.png`;
			} else {
				options.shirt_fitted_clip_src = null;
				options.shirt_fitted_right_move_src = null;
				options.shirt_fitted_left_move_src = null;
			}
		}
		if (options.lower_tucked && !options.worn_lower_setup.notuck && !options.worn_feet_setup.notuck) {
			options.feet_clip_src = "img/clothes/feet/" + options.worn_feet_setup.variable + "/mask.png";
		} else {
			options.feet_clip_src = null;
		}

		options.genitals_chastity = options.worn_genitals_setup.type.includes("chastity");

		if (options.worn_handheld_setup.type.includes("rainproof")) {
			options.handheld_overhead = true;
			if (options.angel_halo_type === "default") { options.angel_halo_lower = true; }
		} else if (["balloon", "heart balloon", "paper fan", "torch"].includes(options.worn_handheld_setup.name)) {
			options.handheld_overhead = true;
			options.angel_halo_lower = false;
		} else {
			options.handheld_overhead = null;
			options.angel_halo_lower = false;
		}

		if (options.worn_handheld_setup.name != "pom poms" && options.worn_handheld_setup.name != "naked" && options.arm_right === "hold") {
			options.handheld_position = true;
		} else {
			options.handheld_position = null;
		}

		options.genitals_chastity = options.worn_genitals_setup.type.includes("chastity");

		if (options.worn_head_setup.name === "cat hoodie hood" && options.worn_upper_setup.name === "cat hoodie") {
			options.hood_damage = true;
		} else {
			options.hood_damage = false;
		}

		if (options.worn_neck_setup.has_collar === 1 && options.worn_upper_setup.has_collar === 1 && !(options.worn_upper_setup.name === "dress shirt" && V.worn.upper.altposition === "alt")) {
			options.nocollar = true;
			options.serafuku = false
		} else if (options.worn_neck_setup.name === "sailor ribbon" && options.worn_upper_setup.name === "serafuku") {
			options.nocollar = false;
			options.serafuku = true
		} else {
			options.nocollar = false;
			options.serafuku = false
		}

		if (options.worn_head_setup.mask_img === 1 && !(options.hood_down && options.worn_head_setup.hood && options.worn_head_setup.outfitSecondary !== undefined)) {
			options.hood_mask = true;
		} else {
			options.hood_mask = null;
		}

		if (options.worn_neck_setup.name === "suspenders" && options.worn_neck_setup.altposition != "alt" &&
			["retro shorts", "retro trousers", "baseball shorts", "wide leg trousers"].includes(options.worn_lower_setup.name)) {
			options.high_waist_suspenders = true;
		} else {
			options.high_waist_suspenders = null;
		}

		/*clothes whose altposition does not include alternate sleeve/full states*/
        if (options.worn_upper_setup.altdisabled) {
			options.worn_upper_setup.altdisabled.includes("sleeves") ? options.alt_without_sleeves = true :
				options.alt_without_sleeves = null;
			options.worn_upper_setup.altdisabled.includes("full") ? options.alt_without_full = true :
				options.alt_without_full = null;
		}
		/*clothes whose sleeves cannot be rolled up*/
		if (options.worn_upper_setup.variable === "schoolcardigan" && options.worn_upper_setup.altposition === "alt") {
			options.alt_sleeve_state = null;
		} else {
			options.alt_sleeve_state = true;
		}
	},
	layers: {
		// banner comments generated in http://patorjk.com/software/taag/#p=display&c=c&f=ANSI%20Regular&t=base
		/***
		 *    ██████   █████  ███████ ███████
		 *    ██   ██ ██   ██ ██      ██
		 *    ██████  ███████ ███████ █████
		 *    ██   ██ ██   ██      ██ ██
		 *    ██████  ██   ██ ███████ ███████
		 *
		 *
		 */
		"base": {
			srcfn(options) {
				if (options.mannequin) return "img/body/mannequin/basenoarms.png"
				else return `img/body/basenoarms-${options.body_type}.png`
			},
			show: true,
			filters: ["body"],
			z: ZIndices.base,
			animation: "idle"
		},
		"basehead": {
			srcfn(options) {
				if (options.mannequin) return "img/body/mannequin/basehead.png"
				return "img/body/basehead.png"
			},
			show: true,
			filters: ["body"],
			z: ZIndices.basehead,
			animation: "idle"
		},
		"breasts": {
			srcfn(options) {
				if (options.mannequin) {
					return "img/body/mannequin/breasts/" +
						(options.breast_size - 1) +
						(options.breasts === "cleavage" && options.breast_size >= 4 ? "_clothed" : "") + ".png"
				} else {
					if (options.breast_size <= 0) return "";
					let fn = "breasts" + options.breast_size + (options.breasts === "cleavage" && options.breast_size >= 3 ? "_clothed" : "") + ".png";
					return "img/body/breasts/" + fn;
				}
			},
			masksrcfn(options) {
				return options.breasts_mask_src;
			},
			showfn(options) {
				return !!options.breasts;
			},
			filters: ["breasts"],
			z: ZIndices.breasts,
			animation: "idle"
		},
		"belly": {
			srcfn(options) {
				if(between(options.belly,1,24)){
					return "img/body/preggyBelly/pregnancy_belly_" + options.belly + ".png";
				}
				return "";
			},
			showfn(options) {
				return !!options.belly;
			},
			filters: ["body"],
			z: ZIndices.bellyBase,
			animation: "idle"
		},
		"nipples_parasite": {
			srcfn(options) {
				switch (options.nipples_parasite) {
					case "urchin":
						return 'img/body/breasts/chestparasite' + options.breast_size + '.png'
					case "slime":
						return 'img/body/breasts/chestslime' + options.breast_size + '.png'
					default:
						return "";
				}
			},
			showfn(options) {
				return !!options.nipples_parasite;
			},
			z: ZIndices.breastsparasite + 0.1,
			animation: "idle"
		},
		"breasts_parasite": {
			srcfn(options) {
				switch (options.breasts_parasite) {
					case "parasite":
						return 'img/body/breasts/breastsparasite' + options.breast_size + '.png'
					default:
						return "";
				}
			},
			showfn(options) {
				return !!options.breasts_parasite;
			},
			filters: ["breasts_parasite"],
			z: ZIndices.breastsparasite,
			animation: "idle"
		},
		"leftarm": {
			srcfn(options) {
				if (options.mannequin) {
					return "img/body/mannequin/leftarmidle.png"
				} else if (options.arm_left === "cover") {
					return "img/body/leftarm.png"
				} else if (options.arm_left === "bound") {
					return `img/body/armboundleft.png`
				} else {
					return `img/body/leftarmidle-${options.body_type}.png`
				}
			},
			showfn(options) {
				return options.arm_left !== "none"
			},
			filters: ["body"],
			zfn(options) {
				return (options.arm_left === "cover" ) ? ZIndices.arms_cover : (ZIndices.base - 2);//改动：前置手臂
			},
			animation: "idle"
		},
		"rightarm": {
			srcfn(options) {
				if (options.mannequin && options.handheld_position) {
					return "img/body/mannequin/rightarmhold.png"
				} else if (options.mannequin) {
					return "img/body/mannequin/rightarmidle.png"
				} else if (options.arm_right === "cover") {
					return "img/body/rightarm.png"
				} else if (options.handheld_position) {
					return "img/body/rightarmhold.png"
				} else if (options.arm_right === "bound") {
					return `img/body/armboundright.png`
				} else {
					return `img/body/rightarmidle-${options.body_type}.png`
				}
			},
			showfn(options) {
				return options.arm_right !== "none"
			},
			filters: ["body"],
			zfn(options) {
				if (options.arm_right === "bound" ||  (options.arm_right === "idle" && !options.LJ_zRarmup )) return (ZIndices.base - 2);
				return ZIndices.arms_cover;
			},
			animation: "idle",
		},

		/***
		 *    ████████  █████  ███    ██ ██      ██ ███    ██ ███████ ███████
		 *       ██    ██   ██ ████   ██ ██      ██ ████   ██ ██      ██
		 *       ██    ███████ ██ ██  ██ ██      ██ ██ ██  ██ █████   ███████
		 *       ██    ██   ██ ██  ██ ██ ██      ██ ██  ██ ██ ██           ██
		 *       ██    ██   ██ ██   ████ ███████ ██ ██   ████ ███████ ███████
		 *
		 *
		 */
		"tan_swimshorts": {
			src: "img/body/tan/under_lower/swimshorts.png",
			showfn(options) {
				return !options.mannequin && options.show_tanlines &&
					options.skin_tone_swimshorts >= 0 &&
					options.skin_tone_swimshorts !== options.skin_tone
			},
			filters: ["swimshorts"],
			zfn(options) {
				return options.ztan_swimshorts
			},
			animation: "idle"
		},
		"tan_swimsuitTop": {
			src: "img/body/tan/under_upper/swimsuit/swimsuit.png",
			showfn(options) {
				return !options.mannequin && options.show_tanlines &&
					options.skin_tone_swimsuitTop >= 0 &&
					options.skin_tone_swimsuitTop !== options.skin_tone
			},
			filters: ["swimsuitTop"],
			zfn(options) {
				return options.ztan_swimsuitTop
			},
			animation: "idle"
		},
		"tan_swimsuitBottom": {
			src: "img/body/tan/under_lower/swimsuit.png",
			showfn(options) {
				return !options.mannequin && options.show_tanlines &&
					options.skin_tone_swimsuitBottom >= 0 &&
					options.skin_tone_swimsuitBottom !== options.skin_tone
			},
			filters: ["swimsuitBottom"],
			zfn(options) {
				return options.ztan_swimsuitBottom
			},
			animation: "idle"
		},
		"tan_bikiniTop": {
			srcfn(options) {
				return "img/body/tan/under_upper/bikini/" + options.breast_size + ".png"
			},
			showfn(options) {
				return !options.mannequin && options.show_tanlines && options.breasts &&
					options.skin_tone_bikiniTop >= 0 &&
					options.skin_tone_bikiniTop !== options.skin_tone
			},
			filters: ["bikiniTop"],
			zfn(options) {
				return options.ztan_bikiniTop
			},
			animation: "idle"
		},
		"tan_bikiniBottom": {
			src: "img/body/tan/under_lower/bikini.png",
			showfn(options) {
				return !options.mannequin && options.show_tanlines &&
					options.skin_tone_bikiniBottom >= 0 &&
					options.skin_tone_bikiniBottom !== options.skin_tone
			},
			filters: ["bikiniBottom"],
			zfn(options) {
				return options.ztan_bikiniBottom
			},
			animation: "idle"
		},

		/***
		 *    ███████  █████   ██████ ███████
		 *    ██      ██   ██ ██      ██
		 *    █████   ███████ ██      █████
		 *    ██      ██   ██ ██      ██
		 *    ██      ██   ██  ██████ ███████
		 *
		 *
		 */
		"facebase": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/base.png'
			},
			showfn(options) {
				return options.show_face
			},
			filters: ["body"],
			z: ZIndices.facebase,
			animation: "idle"
		},
		"freckles": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/freckles.png'
			},
			showfn(options) {
				return options.show_face && !!options.freckles
			},
			filters: ["body"],
			z: ZIndices.freckles
		},
		"ears": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/ears.png'
			},
			showfn(options) {
				return options.show_face && options.ears_position === "front";
			},
			filters: ["body"],
			z: ZIndices.ears
		},
		"eyes": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/eyes.png'
			},
			showfn(options) {
				return options.show_face;
			},
			filters: ["body"],
			z: ZIndices.eyes
		},
		"sclera": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/' + (options.eyes_bloodshot ? "sclerabloodshot" : "sclera") + '.png'
			},
			showfn(options) {
				return options.show_face;
			},
			z: ZIndices.sclera
		},
		"left_iris": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/' + (options.trauma ? "irisempty" : "iris") + (options.eyes_half ? "_halfclosed" : "") + '_left.png'
			},
			showfn(options) {
				return options.show_face;
			},
			filters: ["left_eye"],
			z: ZIndices.iris,
			animation: "idle"
		},
		"right_iris": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/' + (options.trauma ? "irisempty" : "iris") + (options.eyes_half ? "_halfclosed" : "") + '_right.png'
			},
			showfn(options) {
				return options.show_face;
			},
			filters: ["right_eye"],
			z: ZIndices.iris,
			animation: "idle"
		},
		"eyelids": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/eyelids' + (options.eyes_half ? "_halfclosed" : "") + '.png'
			},
			show: true,
			animationfn(options) {
				return options.blink_animation
			},
			filters: ["body"],
			z: ZIndices.eyelids
		},
		"lashes": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/lashes' + (options.eyes_half ? "_halfclosed" : "") + '.png'
			},
			showfn(options) {
				return options.show_face;
			},
			animationfn(options) {
				return options.blink_animation
			},
			z: ZIndices.lashes
		},
		"makeup_eyeshadow": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/makeup/eyeshadows' + (options.eyes_half ? "_halfclosed" : "") + '.png'
			},
			animationfn(options) {
				return options.blink_animation
			},
			showfn(options) {
				return options.show_face && !!options.eyeshadow_colour
			},
			filters: ["eyeshadow"],
			z: ZIndices.eyelids
		},
		"makeup_mascara": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/makeup/mascara' + (options.eyes_half ? "_halfclosed" : "") + '.png'
			},
			animationfn(options) {
				return options.blink_animation
			},
			showfn(options) {
				return options.show_face && !!options.mascara_colour
			},
			filters: ["mascara"],
			z: ZIndices.lashes
		},
		"brows": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/brow' + options.brows + '.png'
			},
			zfn(options) {
				if (options.brows_position === "back") {
					return ZIndices.backbrow
				} else {
					return ZIndices.brow
				}
			},
			showfn(options) {
				return options.show_face && options.brows !== "none"
			},
			filters: ["brows"],
			z: ZIndices.brow
		},
		"mouth": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/mouth' + options.mouth + '.png'
			},
			showfn(options) {
				return options.show_face && options.mouth !== "none"
			},
			filters: ["body"],
			z: ZIndices.mouth
		},
		"makeup_lipstick": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/makeup/lipstick_' + options.mouth + '.png'
			},
			showfn(options) {
				return options.show_face && !!options.lipstick_colour
			},
			filters: ["lipstick"],
			z: ZIndices.mouth
		},
		"blush": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/blush' + options.blush + '.png'
			},
			showfn(options) {
				return options.show_face && options.blush > 0
			},
			filters: ["body"],
			z: ZIndices.blush
		},
		"tears": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/' + 'tear' + options.tears + '.png'
			},
			showfn(options) {
				return options.show_face && options.tears > 0
			},
			z: ZIndices.tears,
			animation: "idle"
		},
		"makeup_mascara_tears": {
			srcfn(options) {
				return 'img/face/' + options.facestyle + '/' + 'makeup/mascara' + options.mascara_running + '.png'
			},
			showfn(options) {
				return options.show_face && options.mascara_running > 0 && !!options.mascara_colour
			},
			filters: ["mascara"],
			z: ZIndices.mascara_running
		},
		"toast": {
			srcfn(options) {
				if (V.trauma > 4000) {
					return 'img/misc/toast_raw.png'
				} else {
					return 'img/misc/toast_buttered.png'
				}
			},
			showfn(options) {
				return options.show_face && !!options.toast
			},
			filters: ["toast"],
			z: ZIndices.toast
		},
		/***
		 *    ██   ██  █████  ██ ██████
		 *    ██   ██ ██   ██ ██ ██   ██
		 *    ███████ ███████ ██ ██████
		 *    ██   ██ ██   ██ ██ ██   ██
		 *    ██   ██ ██   ██ ██ ██   ██
		 *
		 *
		 */
		"hair_sides": {
			srcfn(options) {
				return 'img/hair/sides/' + options.hair_sides_type + '/' + options.hair_sides_length + '.png'
			},
			zfn(options) {
				if (options.hair_sides_position === "front") {
					return ZIndices.hairforwards
				} else {
					return ZIndices.backhair
				}
			},
			masksrcfn(options) {
				return options.head_mask_src;
			},
			showfn(options) {
				return !!options.show_hair && !!options.hair_sides_type
			},
			filters: ["hair"],
			animation: "idle"
		},
		"hair_fringe": {
			srcfn(options) {
				return 'img/hair/fringe/' + options.hair_fringe_type + '/' + options.hair_fringe_length + '.png'
			},
			showfn(options) {
				return !!options.show_hair && !!options.hair_fringe_type
			},
			masksrcfn(options) {
				if (options.head_mask_src) {
					return options.head_mask_src;
				} else {
					return options.fringe_mask_src;
				}
			},
			filters: ["hair_fringe"],
			z: ZIndices.fronthair,
			animation: "idle"
		},
		"hair_extra": { // Extra layer for thighs+ long hair for certain styles
			srcfn(options) {
				if (options.hair_sides_length === "feet" && ["default", "loose", "straight", "curl", "defined curl", "neat", "dreads", "afro pouf", "thick ponytail", "all down", "half-up", "messy ponytail"].includes(options.hair_sides_type)) {
					return "img/hair/back/" + options.hair_sides_type + '/' + "feet.png"
				} else if (options.hair_sides_length === "thighs" && ["default", "loose", "curl", "defined curl", "neat", "dreads", "afro pouf", "thick_ponytail", "all down", "half-up", "messy ponytail"].includes(options.hair_sides_type)) {
					return "img/hair/back/" + options.hair_sides_type + '/' + "thighs.png"
				} else if (options.hair_sides_length === "navel" && ["messy ponytail"].includes(options.hair_sides_type)) {
					return "img/hair/back/" + options.hair_sides_type + '/' + "navel.png"
				} else if (["ruffled"].includes(options.hair_sides_type)) {
					return "img/hair/back/" + options.hair_sides_type + '/' + options.hair_sides_length + ".png"
				} else {
					return ""
				}
			},
			masksrcfn(options) {
				return options.head_mask_src;
			},
			showfn(options) {
				return !!options.show_hair && !!options.hair_sides_type
			},
			filters: ["hair"],
			z: ZIndices.backhair,
			animation: "idle"
		},
		/***
		 *     ██████ ██████   ██████  ████████  ██████ ██   ██
		 *    ██      ██   ██ ██    ██    ██    ██      ██   ██
		 *    ██      ██████  ██    ██    ██    ██      ███████
		 *    ██      ██   ██ ██    ██    ██    ██      ██   ██
		 *     ██████ ██   ██  ██████     ██     ██████ ██   ██
		 *
		 *
		 */
		"pbhair": {
			srcfn(options) {
				return 'img/hair/phair/pb' + options.pbhair_level + '.png'
			},
			showfn(options) {
				return options.crotch_visible &&
					options.pbhair_level > 1 &&
					!options.belly_hides_under_lower &&
					options.pbhair_level !== 4 // $pblevel 4 does not exist
			},
			filters: ["pbhair"],
			z: ZIndices.pbhair,
			animation: "idle"
		},
		"pbhair_strip": {
			srcfn(options) {
				return 'img/hair/phair/pbstrip' + options.pbhair_strip + '.png'
			},
			showfn(options) {
				return options.crotch_visible &&
				options.pbhair_strip >= 1 &&
				!options.belly_hides_under_lower;
			},
			filters: ["pbhair"],
			z: ZIndices.pbhair,
			animation: "idle"
		},
		"pbhair_balls": {
			srcfn(options) {
				return 'img/hair/phair/balls/' + options.penis_size + '_pb' + options.pbhair_balls + '.png'
			},
			showfn(options) {
				return options.crotch_visible &&
					options.pbhair_balls > 1 &&
					options.balls &&
					!options.genitals_chastity
			},
			filters: ["pbhair"],
			zfn(options) {
				return options.crotch_exposed ? ZIndices.pbhairballs : ZIndices.pbhairballsunderclothes
			},
			animation: "idle"
		},
		"penis": {
			srcfn(options) {
				if (options.mannequin) {
					return "img/body/mannequin/penis.png";
				} else if (options.genitals_chastity) {
					if (["chastity belt", "flat chastity cage", "chastity parasite"].includes(options.worn_genitals_setup.name)) return;
					if (options.worn_genitals_setup.name === "small chastity cage") return "img/body/penis/penis_chastitysmall.png";
					return "img/body/penis/penis_chastity.png"
				} else if (!playerHasStrapon()) {
					return "img/body/" +
						(options.balls ? 'penis/' : 'penisnoballs/') +
						(options.penis === "virgin" ? "penis_virgin" : "penis") + options.penis_size + ".png"
				} else {
					return; //if the player has a strapon, then we want to hide their penis
				}
			},
			showfn(options) {
				return options.crotch_visible && !!options.penis;
			},
			filters: ["penis"],
			zfn(options) {
				if (options.crotch_exposed) {
					if (options.genitals_chastity) {
						return ZIndices.penis_chastity
					} else {
						return ZIndices.penis
					}
				} else {
					return ZIndices.penisunderclothes
				}
			},
			animation: "idle"
		},
		"penis_parasite": {
			srcfn(options) {
				if (options.genitals_chastity) {
					if (!options.worn_genitals_setup.name.includes("cage")) return "";
					switch (options.penis_parasite) {
						case "urchin":
							return 'img/clothes/genitals/' + options.worn_genitals_setup.variable + '/urchin.png';
						case "slime":
							return 'img/clothes/genitals/' + options.worn_genitals_setup.variable + '/slime.png';
						default:
							break;
					}
				}
				switch (options.penis_parasite) {
					case "urchin":
						return 'img/body/penis/penisurchin' + options.penis_size + '.png';
					case "slime":
						return 'img/body/penis/penisslime' + options.penis_size + '.png';
					case "parasite":
						return 'img/body/penis/penisparasite' + (options.balls ? 'balls' : '') + options.penis_size + '.png';
					default:
						return "";
				}
			},
			showfn(options) {
				return options.crotch_visible && !!options.penis && !!options.penis_parasite;
			},
			zfn(options) {
				if (options.genitals_chastity) {
					if (options.crotch_exposed) {
						return ZIndices.penis_chastity;
					}else {
						return ZIndices.penisunderclothes;
					}
				} else if (options.crotch_exposed) {
					return ZIndices.parasite;
				} else {
					return ZIndices.underParasite;
				}
			},
			filters: ["penis_parasite"],
			animation: "idle"
		},
		"clit_parasite": {
			srcfn(options) {
				switch (options.clit_parasite) {
					case "urchin":
						return 'img/body/cliturchin.png';
					case "slime":
						return 'img/body/clitslime.png';
					case "parasite":
						return 'img/body/parasitepanty.png';
					case "parasitem":
						return 'img/body/parasiteshorts.png';
					default:
						return "";
				}
			},
			showfn(options) {
				if (options.clit_parasite === "parasite") {
					return !options.belly_hides_under_lower;
				}
				return options.crotch_visible && !!options.clit_parasite && !options.chastity;
			},
			zfn(options) {
				if (["parasite", "parasitem"].includes(options.clit_parasite)) {
					if (options.crotch_exposed) {
						return ZIndices.penis_chastity - 0.1;
					}else {
						return ZIndices.penisunderclothes - 0.1;
					}
				} else if (options.crotch_exposed) {
					return ZIndices.parasite;
				} else {
					return ZIndices.underParasite;
				}
			},
			filters: ["clit_parasite"],
			animation: "idle"
		},
		"penis_condom": {
			srcfn(options) {
				switch (options.penis_condom) {
					case "plain":
						return 'img/body/penis/condom' + options.penis_size + '.png'
					default:
						return "";
				}
			},
			showfn(options) {
				return options.crotch_visible && !!options.penis && !!options.penis_condom && !options.genitals_chastity;
			},
			alpha: 0.4,
			filters: ["condom"],
			zfn(options) {
				if (options.crotch_exposed) {
					return ZIndices.parasite
				} else {
					return ZIndices.underParasite
				}
			},
			animation: "idle"
		},
		/***
		 *    ████████ ███████ ███████
		 *       ██    ██      ██
		 *       ██    █████   ███████
		 *       ██    ██           ██
		 *       ██    ██      ███████
		 *
		 *
		 */

		/***
		 *     █████  ███    ██  ██████  ███████ ██
		 *    ██   ██ ████   ██ ██       ██      ██
		 *    ███████ ██ ██  ██ ██   ███ █████   ██
		 *    ██   ██ ██  ██ ██ ██    ██ ██      ██
		 *    ██   ██ ██   ████  ██████  ███████ ███████
		 *
		 *
		 */
		"angel_wings_right": {
			srcfn(options) {
				return `img/transformations/angel/rightwing/${options.angel_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.angel_wings_type) && options.angel_wing_right === "idle";
			},
			zfn(options) {
				if (options.angel_wings_layer === "back") {
					return ZIndices.head_back
				} else {
					return ZIndices.backhair
				}
			},
			animation: "idle"
		},
		"angel_wings_right_front": {
			srcfn(options) {
				return `img/transformations/angel/rightwing/${options.angel_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.angel_wings_type) && options.angel_wing_right === "idle" && options.angel_wings_type === "default" && options.hair_sides_position !== "front" && options.angel_wings_layer !== "back";
			},
			masksrcfn(options) {
				return `img/transformations/angel/rightwing/${options.angel_wings_type}_mask.png`;
			},
			zfn(options) {
				return ZIndices.over_head
			},
			animation: "idle"
		},
		"angel_wings_rightcover": {
			srcfn(options) {
				return `img/transformations/angel/rightcover/${options.angel_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.angel_wings_type) && options.angel_wing_right === "cover";
			},
			z: ZIndices.tailPenisCover,
			animation: "idle"
		},
		"angel_wings_left": {
			srcfn(options) {
				return `img/transformations/angel/leftwing/${options.angel_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.angel_wings_type) && options.angel_wing_left === "idle";
			},
			zfn(options) {
				if (options.angel_wings_layer === "back") {
					return ZIndices.head_back
				} else {
					return ZIndices.backhair
				}
			},
			animation: "idle"
		},
		"angel_wings_left_back": {
			srcfn(options) {
				return `img/transformations/angel/leftwing/${options.angel_wings_type}_back.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.angel_wings_type) && options.angel_wings_type === "default" && options.angel_wing_left === "idle";
			},
			zfn(options) {
				return ZIndices.head_back;
			},
			animation: "idle"
		},
		"angel_wings_left_front": {
			srcfn(options) {
				return `img/transformations/angel/leftwing/${options.angel_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.angel_wings_type) && options.angel_wing_left === "idle" && options.angel_wings_type === "default" && options.angel_wings_layer !== "back";
			},
			masksrcfn(options) {
				return `img/transformations/angel/leftwing/${options.angel_wings_type}_mask.png`;
			},
			zfn(options) {
				return ZIndices.over_head
			},
			animation: "idle"
		},
		"angel_wings_leftcover": {
			srcfn(options) {
				return `img/transformations/angel/leftcover/${options.angel_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.angel_wings_type) && options.angel_wing_left === "cover";
			},
			z: ZIndices.tailPenisCover,
			animation: "idle"
		},
		"angel_halo_back": {
			srcfn(options) {
				return `img/transformations/angel/backhalo/${options.angel_halo_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.angel_halo_type);
			},
			dyfn(options) {
				return options.angel_halo_lower && isPartEnabled(options.angel_halo_type) ? 20 : 0;
			},
			zfn(options) {
				return options.angel_halo_lower && isPartEnabled(options.angel_halo_type) ? ZIndices.head_back : ZIndices.over_head_back;
			},
			animation: "idle"
		},
		"angel_halo_front": {
			srcfn(options) {
				return `img/transformations/angel/fronthalo/${options.angel_halo_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.angel_halo_type);
			},
			dyfn(options) {
				return options.angel_halo_lower && isPartEnabled(options.angel_halo_type) ? 20 : 0;
			},
			zfn(options) {
				return options.angel_halo_lower && isPartEnabled(options.angel_halo_type) ? ZIndices.over_head : ZIndices.over_upper;
			},
			animation: "idle"
		},

		/***
		 *    ███████  █████  ██      ██      ███████ ███    ██
		 *    ██      ██   ██ ██      ██      ██      ████   ██
		 *    █████   ███████ ██      ██      █████   ██ ██  ██
		 *    ██      ██   ██ ██      ██      ██      ██  ██ ██
		 *    ██      ██   ██ ███████ ███████ ███████ ██   ████
		 *
		 *
		 */
		"fallen_wings_right": {
			srcfn(options) {
				return `img/transformations/fallen/rightwing/${options.fallen_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.fallen_wings_type) && options.fallen_wing_right === "idle";
			},
			zfn(options) {
				if (options.fallen_wings_layer === "back") {
					return ZIndices.head_back
				} else {
					return ZIndices.backhair
				}
			},
			animation: "idle"
		},
		"fallen_wings_right_front": {
			srcfn(options) {
				return `img/transformations/fallen/rightwing/${options.fallen_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.fallen_wings_type) && options.fallen_wing_right === "idle" && ["default", "fallenplus"].includes(options.fallen_wings_type) && options.hair_sides_position !== "front" && options.fallen_wings_layer !== "back";
			},
			masksrcfn(options) {
				return `img/transformations/fallen/rightwing/${options.fallen_wings_type}_mask.png`;
			},
			zfn(options) {
				return ZIndices.over_head;
			},
			animation: "idle"
		},
		"fallen_wings_rightcover": {
			srcfn(options) {
				return `img/transformations/fallen/rightcover/${options.fallen_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.fallen_wings_type) && options.fallen_wing_right === "cover";
			},
			z: ZIndices.tailPenisCover,
			animation: "idle"
		},
		"fallen_wings_left": {
			srcfn(options) {
				return `img/transformations/fallen/leftwing/${options.fallen_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.fallen_wings_type) && options.fallen_wing_left === "idle";
			},
			zfn(options) {
				if (options.fallen_wings_layer === "back") {
					return ZIndices.head_back
				} else {
					return ZIndices.backhair
				}
			},
			animation: "idle"
		},
		"fallen_wings_left_front": {
			srcfn(options) {
				return `img/transformations/fallen/leftwing/${options.fallen_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.fallen_wings_type) && options.fallen_wing_left === "idle" && ["default", "fallenplus"].includes(options.fallen_wings_type) && options.hair_sides_position !== "front" && options.fallen_wings_layer !== "back";
			},
			masksrcfn(options) {
				return `img/transformations/fallen/leftwing/${options.fallen_wings_type}_mask.png`;
			},
			zfn(options) {
				return ZIndices.over_head;
			},
			animation: "idle"
		},
		"fallen_wings_leftcover": {
			srcfn(options) {
				return `img/transformations/fallen/leftcover/${options.fallen_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.fallen_wings_type) && options.fallen_wing_left === "cover";
			},
			z: ZIndices.tailPenisCover,
			animation: "idle"
		},
		"fallen_halo_back": {
			srcfn(options) {
				return `img/transformations/fallen/backbrokenhalo/${options.fallen_halo_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.fallen_halo_type);
			},
			z: ZIndices.over_head_back,
			animation: "idle"
		},
		"fallen_halo_front": {
			srcfn(options) {
				return `img/transformations/fallen/frontbrokenhalo/${options.fallen_halo_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.fallen_halo_type);
			},
			z: ZIndices.over_upper,
			animation: "idle"
		},

		/***
		 *    ██████  ███████ ███    ███  ██████  ███    ██
		 *    ██   ██ ██      ████  ████ ██    ██ ████   ██
		 *    ██   ██ █████   ██ ████ ██ ██    ██ ██ ██  ██
		 *    ██   ██ ██      ██  ██  ██ ██    ██ ██  ██ ██
		 *    ██████  ███████ ██      ██  ██████  ██   ████
		 *
		 *
		 */
		"demon_wings": {
			srcfn(options) {
				return `img/transformations/demon/wings/${options.demon_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.demon_wings_type) && !isPartEnabled(options.bird_wings_type) && options.demon_wings_state === "idle";
			},
			zfn(options) {
				if (options.demon_wings_layer === "back") {
					return ZIndices.head_back
				} else if (options.demon_wings_layer === "cover") {
					return ZIndices.tailPenisCover
				} else {
					return ZIndices.backhair
				}
			},
			z: ZIndices.backhair,
			filters: ["demon_wings"],
			animation: "idle"
		},
		"demon_wings_flaunt": {
			srcfn(options) {
				return `img/transformations/demon/flauntwings/${options.demon_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.demon_wings_type) && options.demon_wings_state === "flaunt";
			},
			z: ZIndices.tailPenisCover,
			filters: ["demon_wings"],
			animation: "idle"
		},
		"demon_wings_cover": {
			srcfn(options) {
				return `img/transformations/demon/leftcover/${options.demon_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.demon_wings_type) && options.demon_wings_state === "cover";
			},
			z: ZIndices.tailPenisCover,
			filters: ["demon_wings"],
			animation: "idle"
		},
		"demon_tail": {
			srcfn(options) {
				return `img/transformations/demon/tail/${options.demon_tail_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.demon_tail_type) && options.demon_tail_state === "idle"
			},
			zfn(options) {
				if (options.demon_tail_layer === "back") {
					return ZIndices.tail
				} else if (options.demon_tail_layer === "cover") {
					return ZIndices.tailPenisCoverOverlay
				} else {
					return ZIndices.back_lower
				}
			},
			filters: ["demon_tail"],
			animation: "idle"
		},
		"demon_tail_flaunt": {
			srcfn(options) {
				return `img/transformations/demon/flaunttail/${options.demon_tail_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.demon_tail_type) && options.demon_tail_state === "flaunt";
			},
			z: ZIndices.tailPenisCoverOverlay,
			filters: ["demon_tail"],
			animation: "idle"
		},
		"demon_tail_cover": {
			srcfn(options) {
				return `img/transformations/demon/rightcover/${options.demon_tail_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.demon_tail_type) && options.demon_tail_state === "cover";
			},
			z: ZIndices.tailPenisCoverOverlay,
			filters: ["demon_tail"],
			animation: "idle"
		},
		"demon_horns": {
			srcfn(options) {
				return `img/transformations/demon/horns/${options.demon_horns_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.demon_horns_type);
			},
			zfn(options) {
				if (options.demon_horns_layer === "front") {
					return ZIndices.over_head
				} else {
					return ZIndices.horns
				}
			},
			masksrcfn(options){
				if (options.demon_horns_layer !== "front") {
					return options.head_mask_src
				} else {
					return null
				}
			},
			z: ZIndices.horns,
			filters: ["demon_horns"],
			animation: "idle"
		},
		/***
		 *    ██     ██  ██████  ██      ███████
		 *    ██     ██ ██    ██ ██      ██
		 *    ██  █  ██ ██    ██ ██      █████
		 *    ██ ███ ██ ██    ██ ██      ██
		 *     ███ ███   ██████  ███████ ██
		 *
		 *
		 */
		"wolf_tail": {
			srcfn(options) {
				return `img/transformations/wolf/tail/${options.wolf_tail_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.wolf_tail_type);
			},
			filters: ["hair"],
			zfn(options) {
				if (options.wolf_tail_layer === "back") {
					return ZIndices.tail
				} else {
					return ZIndices.back_lower
				}
			},
			animation: "idle"
		},
		"wolf_ears": {
			srcfn(options) {
				return `img/transformations/wolf/ears/${options.wolf_ears_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.wolf_ears_type);
			},
			masksrcfn(options) {
				return options.head_mask_src;
			},
			filters: ["hair"],
			z: ZIndices.backhair,
			animation: "idle"
		},
		"wolf_pits": {
			srcfn(options) {
				return `img/transformations/hirsute/pits/${options.wolf_pits_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.wolf_pits_type);
			},
			filters: ["hair"],
			z: ZIndices.hirsute,
			animation: "idle"
		},
		"wolf_pubes": {
			srcfn(options) {
				return `img/transformations/hirsute/pubes/${options.wolf_pubes_type}.png`;
			},
			showfn(options) {
				return options.show_tf
				&& isPartEnabled(options.wolf_pubes_type)
				&& !options.belly_hides_under_lower;
			},
			filters: ["hair"],
			z: ZIndices.hirsute,
			animation: "idle"
		},
		"wolf_cheeks": {
			srcfn(options) {
				return `img/transformations/wolf/cheeks/${options.wolf_cheeks_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.wolf_cheeks_type);
			},
			filters: ["hair"],
			z: ZIndices.lower,
			animation: "idle"
		},
		/***
		 *     ██████  █████  ████████
		 *    ██      ██   ██    ██
		 *    ██      ███████    ██
		 *    ██      ██   ██    ██
		 *     ██████ ██   ██    ██
		 *
		 *
		 */

		"cat_tail": {
			srcfn(options) {
				return `img/transformations/cat/tail/${options.cat_tail_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.cat_tail_type) && options.cat_tail_state === "idle";
			},
			filters: ["hair"],
			zfn(options) {
				if (options.cat_tail_layer === "back") {
					return ZIndices.tail
				} else {
					return ZIndices.back_lower
				}
			},
			animation: "idle"
		},
		"cat_tail_flaunt": {
			srcfn(options) {
				return `img/transformations/cat/flaunttail/${options.cat_tail_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.cat_tail_type) && options.cat_tail_state === "flaunt";
			},
			z: ZIndices.tailPenisCover,
			filters: ["hair"],
			animation: "idle"
		},
		"cat_tail_cover": {
			srcfn(options) {
				return `img/transformations/cat/covertail/${options.cat_tail_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.cat_tail_type) && options.cat_tail_state === "cover";
			},
			z: ZIndices.tailPenisCover,
			filters: ["hair"],
			animation: "idle"
		},
		"cat_ears": {
			srcfn(options) {
				return `img/transformations/cat/ears/${options.cat_ears_type}.png`;
			},
			masksrcfn(options) {
				return options.head_mask_src;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.cat_ears_type);
			},
			filters: ["hair"],
			z: ZIndices.backhair,
			animation: "idle"
		},
		/***
		 *     ██████  ██████  ██     ██
		 *    ██      ██    ██ ██     ██
		 *    ██      ██    ██ ██  █  ██
		 *    ██      ██    ██ ██ ███ ██
		 *     ██████  ██████   ███ ███
		 *
		 *
		 */
		"cow_horns": {
			srcfn(options) {
				return `img/transformations/cow/horns/${options.cow_horns_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.cow_horns_type);
			},
			zfn(options) {
				if (options.cow_horns_layer === "front") {
					return ZIndices.over_head
				} else {
					return ZIndices.horns
				}
			},
			masksrcfn(options){
				if (options.cow_horns_layer !== "front") {
					return options.head_mask_src
				} else {
					return null
				}
			},
			animation: "idle"
		},
		"cow_ears": {
			srcfn(options) {
				return `img/transformations/cow/ears/${options.cow_ears_type}.png`;
			},
			masksrcfn(options) {
				return options.head_mask_src;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.cow_ears_type);
			},
			z: ZIndices.horns,
			animation: "idle"
		},
		"cow_tag": {
			srcfn(options) {
				return "img/transformations/cow/tag.png";
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.cow_ears_type);
			},
			z: ZIndices.face,
			animation: "idle"
		},
		"cow_tail": {
			srcfn(options) {
				return `img/transformations/cow/tail/${options.cow_tail_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.cow_tail_type);
			},
			zfn(options) {
				if (options.cow_tail_layer === "back") {
					return ZIndices.tail
				} else {
					return ZIndices.back_lower
				}
			},
			animation: "idle"
		},
		/***
		 *    ██████  ██ ██████  ██████
		 *    ██   ██ ██ ██   ██ ██   ██
		 *    ██████  ██ ██████  ██   ██
		 *    ██   ██ ██ ██   ██ ██   ██
		 *    ██████  ██ ██   ██ ██████
		 *
		 *
		 */

		"bird_wings_right": {
			srcfn(options) {
				return `img/transformations/bird/rightwing/${options.bird_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.bird_wings_type) && options.bird_wing_right === "idle";
			},
			filters: ["hair"],
			zfn(options) {
				if (options.bird_wings_layer === "back") {
					return ZIndices.head_back
				} else {
					return ZIndices.backhair
				}
			},
			animation: "idle"
		},
		"bird_wings_rightcover": {
			srcfn(options) {
				return `img/transformations/bird/rightcover/${options.bird_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.bird_wings_type) && options.bird_wing_right === "cover";
			},
			filters: ["hair"],
			z: ZIndices.tailPenisCover,
			animation: "idle"
		},
		"bird_wings_left": {
			srcfn(options) {
				return `img/transformations/bird/leftwing/${options.bird_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.bird_wings_type) && options.bird_wing_left === "idle";
			},
			filters: ["hair"],
			zfn(options) {
				if (options.bird_wings_layer === "back") {
					return ZIndices.head_back
				} else {
					return ZIndices.backhair
				}
			},
			animation: "idle"
		},
		"bird_wings_leftcover": {
			srcfn(options) {
				return `img/transformations/bird/leftcover/${options.bird_wings_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.bird_wings_type) && options.bird_wing_left === "cover";
			},
			filters: ["hair"],
			z: ZIndices.tailPenisCover,
			animation: "idle"
		},
		"bird_tail": {
			srcfn(options) {
				return `img/transformations/bird/tail/${options.bird_tail_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.bird_tail_type);
			},
			filters: ["hair"],
			zfn(options) {
				if (options.bird_tail_layer === "back") {
					return ZIndices.tail
				} else {
					return ZIndices.back_lower
				}
			},
			animation: "idle"
		},
		"bird_eyes": {
			srcfn(options) {
				return `img/transformations/bird/eyes/${options.bird_eyes_type}.png`;
			},
			showfn(options) {
				return options.show_tf && options.show_face && isPartEnabled(options.bird_eyes_type);
			},
			z: ZIndices.irisacc,
			animation: "idle"
		},
		"bird_malar": {
			srcfn(options) {
				return `img/transformations/bird/malar/${options.bird_malar_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.bird_malar_type);
			},
			filters: ["hair"],
			z: ZIndices.lower,
			animation: "idle"
		},
		"bird_plumage": {
			srcfn(options) {
				return `img/transformations/bird/plumage/${options.bird_plumage_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.bird_plumage_type);
			},
			filters: ["hair"],
			z: ZIndices.lower,
			animation: "idle"
		},
		"bird_pubes": {
			srcfn(options) {
				return `img/transformations/bird/pubes/${options.bird_pubes_type}.png`;
			},
			showfn(options) {
				return options.show_tf
				&& isPartEnabled(options.bird_pubes_type)
				&& !options.belly_hides_under_lower;
			},
			filters: ["hair"],
			z: ZIndices.hirsute,
			animation: "idle"
		},
		/***
		 *    ███████  ██████  ██   ██
		 *    ██      ██    ██  ██ ██
		 *    █████   ██    ██   ███
		 *    ██      ██    ██  ██ ██
		 *    ██       ██████  ██   ██
		 *
		 *
		 */
		"fox_tail": {
			srcfn(options) {
				return `img/transformations/fox/tail/${options.fox_tail_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.fox_tail_type);
			},
			filters: ["hair"],
			zfn(options) {
				if (options.fox_tail_layer === "back") {
					return ZIndices.tail
				} else {
					return ZIndices.back_lower
				}
			},
			animation: "idle"
		},
		"fox_ears": {
			srcfn(options) {
				return `img/transformations/fox/ears/${options.fox_ears_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.fox_ears_type);
			},
			masksrcfn(options) {
				return options.head_mask_src;
			},
			filters: ["hair"],
			z: ZIndices.backhair,
			animation: "idle"
		},
		"fox_cheeks": {
			srcfn(options) {
				return `img/transformations/fox/cheeks/${options.fox_cheeks_type}.png`;
			},
			showfn(options) {
				return options.show_tf && isPartEnabled(options.fox_cheeks_type);
			},
			filters: ["hair"],
			z: ZIndices.lower,
			animation: "idle"
		},
		/***
		 *    ██     ██ ██████  ██ ████████ ██ ███    ██  ██████  ███████
		 *    ██     ██ ██   ██ ██    ██    ██ ████   ██ ██       ██
		 *    ██  █  ██ ██████  ██    ██    ██ ██ ██  ██ ██   ███ ███████
		 *    ██ ███ ██ ██   ██ ██    ██    ██ ██  ██ ██ ██    ██      ██
		 *     ███ ███  ██   ██ ██    ██    ██ ██   ████  ██████  ███████
		 *
		 *
		 */
		"writing_forehead": {
			srcfn(options) {
				const area_name = "forehead"
				let writing = setup.bodywriting[options.writing_forehead];
				if (writing.type === "text") {
					if (writing.sprites && writing.sprites.length > 0 && writing.sprites.includes(area_name)) {
						return 'img/bodywriting/text/' + writing.key + '/' + area_name + '.png';
					}
					return 'img/bodywriting/text/default/' + area_name + '.png';
				} else if (writing.type === "object") {
					return 'img/bodywriting/' + writing.writing + '/' + area_name + '.png'
				} else {
					return '';
				}
			},
			showfn(options) {
				return options.show_writings && !!options.writing_forehead;
			},
			z: ZIndices.skin,
			animation: "idle"
		},
		"writing_left_cheek": {
			srcfn(options) {
				const area_name = "left_cheek"
				let writing = setup.bodywriting[options.writing_left_cheek];
				if (writing.type === "text") {
					if (writing.sprites && writing.sprites.length > 0 && writing.sprites.includes(area_name)) {
						return 'img/bodywriting/text/' + writing.key + '/' + area_name + '.png';
					}
					return 'img/bodywriting/text/default/' + area_name + '.png';
				} else if (writing.type === "object") {
					return 'img/bodywriting/' + writing.writing + '/' + area_name + '.png'
				} else {
					return '';
				}
			},
			showfn(options) {
				return options.show_writings && !!options.writing_left_cheek;
			},
			z: ZIndices.skin,
			animation: "idle"
		},
		"writing_right_cheek": {
			srcfn(options) {
				const area_name = "right_cheek"
				let writing = setup.bodywriting[options.writing_right_cheek];
				if (writing.type === "text") {
					if (writing.sprites && writing.sprites.length > 0 && writing.sprites.includes(area_name)) {
						return 'img/bodywriting/text/' + writing.key + '/' + area_name + '.png';
					}
					return 'img/bodywriting/text/default/' + area_name + '.png';
				} else if (writing.type === "object") {
					return 'img/bodywriting/' + writing.writing + '/' + area_name + (writing.arrow ? "_arrow" : "") + '.png'
				} else {
					return '';
				}
			},
			showfn(options) {
				return options.show_writings && !!options.writing_right_cheek;
			},
			z: ZIndices.skin,
			animation: "idle"
		},
		"writing_breasts": {
			srcfn(options) {
				const area_name = "breasts"
				let writing = setup.bodywriting[options.writing_breasts];
				if (writing.type === "text") {
					if (writing.sprites && writing.sprites.length > 0 && writing.sprites.includes(area_name)) {
						return 'img/bodywriting/text/' + writing.key + '/' + area_name + '.png';
					}
					return 'img/bodywriting/text/default/' + area_name + '1.png';
				} else if (writing.type === "object") {
					return 'img/bodywriting/' + writing.writing + '/breasts' + options.breast_size + '.png'
				} else {
					return '';
				}
			},
			showfn(options) {
				return options.show_writings && !!options.writing_breasts;
			},
			z: ZIndices.skin,
			animation: "idle"
		},
		"writing_breasts_extra": {
			srcfn(options) {
				let writing = setup.bodywriting[options.writing_breasts];
				if ((!writing.sprites || writing.sprites.length == 0) && writing.type === "text" && options.breast_size >= 2) {
					return 'img/bodywriting/text/default/breasts' + options.breast_size + '.png'
				} else {
					return '';
				}
			},
			showfn(options) {
				return options.show_writings && !!options.writing_breasts;
			},
			z: ZIndices.skin,
			animation: "idle"
		},
		"writing_left_shoulder": {
			srcfn(options) {
				const area_name = "left_shoulder"
				let writing = setup.bodywriting[options.writing_left_shoulder];
				if (writing.type === "text") {
					if (writing.sprites && writing.sprites.length > 0 && writing.sprites.includes(area_name)) {
						return 'img/bodywriting/text/' + writing.key + '/' + area_name + '.png';
					}
					return 'img/bodywriting/text/default/' + area_name + '.png';
				} else if (writing.type === "object") {
					return 'img/bodywriting/' + writing.writing + '/' + area_name + '.png'
				} else {
					return '';
				}
			},
			showfn(options) {
				return options.show_writings && !!options.writing_left_shoulder;
			},
			zfn(options) {//改动：前置手臂纹身，
				return (options.arm_left === "bound"  || options.arm_left === "idle" ) ? (ZIndices.base - 1.9) : (ZIndices.arms_cover + 0.1);
			},
			animation: "idle"
		},
		"writing_right_shoulder": {
			srcfn(options) {
				const area_name = "right_shoulder"
				let writing = setup.bodywriting[options.writing_right_shoulder];
				if (writing.type === "text") {
					if (writing.sprites && writing.sprites.length > 0 && writing.sprites.includes(area_name)) {
						return 'img/bodywriting/text/' + writing.key + '/' + area_name + '.png';
					}
					return 'img/bodywriting/text/default/' + area_name + '.png';
				} else if (writing.type === "object") {
					return 'img/bodywriting/' + writing.writing + '/' + area_name + '.png'
				} else {
					return '';
				}
			},
			showfn(options) {
				return options.show_writings && !!options.writing_right_shoulder;
			},
			zfn(options) {//改动：前置手臂纹身
				return (options.arm_right === "bound"  || (options.arm_right === "idle" && !options.LJ_zRarmup )) ? (ZIndices.base - 1.9) : (ZIndices.arms_cover + 0.1);
			},
			animation: "idle"
		},
		"writing_pubic": {
			srcfn(options) {
				const area_name = "pubic"
				let writing = setup.bodywriting[options.writing_pubic];
				if (writing.type === "text") {
					if (writing.sprites && writing.sprites.length > 0 && writing.sprites.includes(area_name)) {
						return 'img/bodywriting/text/' + writing.key + '/' + area_name + '.png';
					}
					return 'img/bodywriting/text/default/' + area_name + (writing.arrow ? "_arrow" : "") + '.png';
				} else if (writing.type === "object") {
					return 'img/bodywriting/' + writing.writing + '/' + area_name + '.png'
				} else {
					return '';
				}
			},
			showfn(options) {
				return options.show_writings && !!options.writing_pubic;
			},
			z: ZIndices.skin,
			animation: "idle"
		},
		"writing_left_thigh": {
			srcfn(options) {
				const area_name = "left_thigh"
				let writing = setup.bodywriting[options.writing_left_thigh];
				if (writing.type === "text") {
					if (writing.sprites && writing.sprites.length > 0 && writing.sprites.includes(area_name)) {
						return 'img/bodywriting/text/' + writing.key + '/' + area_name + '.png';
					}
					return 'img/bodywriting/text/default/' + area_name + (writing.arrow ? "_arrow" : "") + '.png';
				} else if (writing.type === "object") {
					return 'img/bodywriting/' + writing.writing + '/' + area_name + '.png'
				} else {
					return '';
				}
			},
			showfn(options) {
				return options.show_writings && !!options.writing_left_thigh;
			},
			z: ZIndices.skin,
			animation: "idle"
		},
		"writing_right_thigh": {
			srcfn(options) {
				const area_name = "right_thigh"
				let writing = setup.bodywriting[options.writing_right_thigh];
				if (writing.type === "text") {
					if (writing.sprites && writing.sprites.length > 0 && writing.sprites.includes(area_name)) {
						return 'img/bodywriting/text/' + writing.key + '/' + area_name + '.png';
					}
					return 'img/bodywriting/text/default/' + area_name + (writing.arrow ? "_arrow" : "") + '.png';
				} else if (writing.type === "object") {
					return 'img/bodywriting/' + writing.writing + '/' + area_name + '.png'
				} else {
					return '';
				}
			},
			showfn(options) {
				return !!options.writing_right_thigh;
			},
			z: ZIndices.skin,
			animation: "idle"
		},

		/***
		 *    ██████  ██████  ██ ██████  ███████
		 *    ██   ██ ██   ██ ██ ██   ██ ██
		 *    ██   ██ ██████  ██ ██████  ███████
		 *    ██   ██ ██   ██ ██ ██           ██
		 *    ██████  ██   ██ ██ ██      ███████
		 *
		 *
		 */

		"drip_vaginal": {
			srcfn(options) {
				return "img/body/cum/VaginalCumDrip" + options.drip_vaginal + ".png"
			},
			showfn(options) {
				return !!options.drip_vaginal;
			},
			z: ZIndices.tears,
			animationfn(options) {
				return "VaginalCumDrip" + options.drip_vaginal;
			}
		},
		"drip_anal": {
			srcfn(options) {
				return "img/body/cum/AnalCumDrip" + options.drip_anal + ".png"
			},
			showfn(options) {
				return !!options.drip_anal;
			},
			z: ZIndices.tears,
			animationfn(options) {
				return "AnalCumDrip" + options.drip_anal;
			}
		},
		"drip_mouth": {
			srcfn(options) {
				return "img/body/cum/MouthCumDrip" + options.drip_mouth + ".png"
			},
			showfn(options) {
				return options.show_face && !!options.drip_mouth && !options.worn_face_setup.type.includesAny("mask", "covered");
			},
			dxfn(options) {
				return options.facestyle === "small-eyes" ? 2 : 0;
			},
			z: ZIndices.semencough,
			animationfn(options) {
				return "MouthCumDrip" + options.drip_mouth;
			}
		},
		"cum_chest": {
			srcfn(options) {
				return "img/body/cum/Chest " + options.cum_chest + ".png"
			},
			showfn(options) {
				return !!options.cum_chest;
			},
			z: ZIndices.tears,
			animation: "idle"
		},
		"cum_face": {
			srcfn(options) {
				return "img/body/cum/Face " + options.cum_face + ".png"
			},
			showfn(options) {
				return options.show_face && !!options.cum_face;
			},
			z: ZIndices.tears,
			animation: "idle"
		},
		"cum_feet": {
			srcfn(options) {
				return "img/body/cum/Feet " + options.cum_feet + ".png"
			},
			showfn(options) {
				return !!options.cum_feet;
			},
			z: ZIndices.tears,
			animation: "idle"
		},
		"cum_leftarm": {
			srcfn(options) {
				return "img/body/cum/Left Arm " + options.cum_leftarm + ".png"
			},
			showfn(options) {
				return options.arm_left !== "none" && options.arm_left != "cover" && !!options.cum_leftarm;
			},
			z: ZIndices.tears,
			animation: "idle"
		},
		"cum_rightarm": {
			srcfn(options) {
				return "img/body/cum/Right Arm " + options.cum_rightarm + ".png"
			},
			showfn(options) {
				return options.arm_right !== "none" && options.arm_right != "cover" && options.arm_right != "hold" && !!options.cum_rightarm;
			},
			z: ZIndices.tears,
			animation: "idle"
		},
		"cum_neck": {
			srcfn(options) {
				return "img/body/cum/Neck " + options.cum_neck + ".png"
			},
			showfn(options) {
				return !!options.cum_neck;
			},
			z: ZIndices.tears,
			animation: "idle"
		},
		"cum_thigh": {
			srcfn(options) {
				return "img/body/cum/Thighs " + options.cum_thigh + ".png"
			},
			showfn(options) {
				return !!options.cum_thigh;
			},
			z: ZIndices.tears,
			animation: "idle"
		},
		"cum_tummy": {
			srcfn(options) {
				return "img/body/cum/Tummy " + options.cum_tummy + ".png"
			},
			showfn(options) {
				return !!options.cum_tummy;
			},
			z: ZIndices.tears,
			animation: "idle"
		},
		/***
		 *     ██████ ██       ██████  ████████ ██   ██ ███████ ███████
		 *    ██      ██      ██    ██    ██    ██   ██ ██      ██
		 *    ██      ██      ██    ██    ██    ███████ █████   ███████
		 *    ██      ██      ██    ██    ██    ██   ██ ██           ██
		 *     ██████ ███████  ██████     ██    ██   ██ ███████ ███████
		 *
		 *
		 */
		/***
		 *    ██    ██ ██████  ██████  ███████ ██████
		 *    ██    ██ ██   ██ ██   ██ ██      ██   ██
		 *    ██    ██ ██████  ██████  █████   ██████
		 *    ██    ██ ██      ██      ██      ██   ██
		 *     ██████  ██      ██      ███████ ██   ██
		 *
		 *
		 */
		"upper_main": genlayer_clothing_main('upper', {
			zfn(options) {
				return options.worn_upper_setup.name === "cocoon" ? ZIndices.over_head : options.zupper;
			},
			masksrcfn(options) {
				if (options.belly >= 7) {
					return options.shirt_mask_clip_src;
				} else {
					return options.worn_upper_setup.formfitting && options.shirt_fitted_clip_src;
				}
			}
		}),
		"upper_fitted_left": genlayer_clothing_fitted_left("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_fitted_left_move_src;
			},
			dxfn(options) {
				return -1;
			},
		}),
		"upper_fitted_right": genlayer_clothing_fitted_right("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_fitted_right_move_src;
			},
			dxfn(options) {
				return 1;
			},
		}),
		"upper_belly_split_shadow": genlayer_clothing_belly_split("upper", {
			zfn(options) {
				return options.zupper-1
			},
			masksrcfn(options) {
				return options.shirt_mask_clip_src;
			},
			dyfn(options) {
				if (options.shirt_move_left_src) {
					return 2;
				} else {
					return 0;
				}
			},
			dxfn(options) {
				return 0;
			},
			brightnessfn(options){
				if (options.shirt_move_left_src) {
					return -.3;
				} else {
					return 0;
				}
			}
		}),
		"upper_belly_split_l": genlayer_clothing_belly_split("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_move_left_src;
			},
			dxfn(options) {
				if (options.shirt_move_left_src) {
					if (options.belly >= 22) {
						return 12;
					} else {
						return 8;
					}
				} else {
					return 0;
				}
			},
			dyfn(options) {
				if (options.shirt_move_left_src) {
					return -2;
				} else {
					return 0;
				}
			},
		}),
		"upper_belly_split_l2": genlayer_clothing_belly_split("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_move_left2_src;
			},
			dxfn(options) {
				if (options.shirt_move_left2_src) {
					if (options.belly >= 22) {
						return 14;
					} else {
						return 10;
					}
				} else {
					return 0;
				}
			},
			dyfn(options) {
				if (options.shirt_move_left2_src) {
					return 0;
				} else {
					return 0;
				}
			},
		}),
		"upper_belly_split_l_shadow": genlayer_clothing_belly_split("upper", {
			zfn(options) {
				return options.zupper-1
			},
			masksrcfn(options) {
				return options.shirt_move_left_src;
			},
			dxfn(options) {
				if (options.shirt_move_left_src) {
					if (options.belly >= 22) {
						return 14;
					} else {
						return 10;
					}
				} else {
					return 0;
				}
			},
			dyfn(options) {
				if (options.shirt_move_left_src) {
					return -2;
				} else {
					return 0;
				}
			},
			brightnessfn(options){
				if (options.shirt_move_left_src) {
					return -.3;
				} else {
					return 0;
				}
			}
		}),
		"upper_belly_split_l2_shadow": genlayer_clothing_belly_split("upper", {
			zfn(options) {
				return options.zupper-1
			},
			masksrcfn(options) {
				return options.shirt_move_left2_src;
			},
			dxfn(options) {
				if (options.shirt_move_left2_src) {
					if (options.belly >= 22) {
						return 16;
					} else {
						return 12;
					}
				} else {
					return 0;
				}
			},
			dyfn(options) {
				if (options.shirt_move_left2_src) {
					return 0;
				} else {
					return 0;
				}
			},
			brightnessfn(options){
				if (options.shirt_move_left_src) {
					return -.3;
				} else {
					return 0;
				}
			}
		}),
		"upper_belly_split_r": genlayer_clothing_belly_split("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_move_right_src;
			}
		}),
		"upper_belly_split_r2": genlayer_clothing_belly_split("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_move_right2_src;
			},
			dxfn(options) {
				if (options.shirt_move_right2_src) {
					return -4;
				}
			},
		}),
		"upper_belly_split_r3": genlayer_clothing_belly_split("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_move_right3_src;
			},
			dxfn(options) {
				if (options.shirt_move_right3_src) {
					return -6;
				}
			},
		}),
		"upper_belly_2": genlayer_clothing_belly_2("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.belly_mask_src;
			}
		}),
		"upper_belly": genlayer_clothing_belly("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.belly_mask_src;
			}
		}),
		/*** Did not work
		"upper_belly_shadow": genlayer_clothing_belly_highlight("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.belly_mask_upper_shadow_src;
			}
		}),
		*/
		"upper_belly_acc": genlayer_clothing_belly_acc("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.belly_mask_src;
			}
		}),
		"upper_belly_split_acc_shadow": genlayer_clothing_belly_split_acc("upper", {
			zfn(options) {
				return options.zupper-1
			},
			masksrcfn(options) {
				return options.shirt_mask_clip_src;
			},
			dyfn(options) {
				if (options.shirt_move_left_src) {
					return 2;
				} else {
					return 0;
				}
			},
			dxfn(options) {
				return 0;
			},
			brightnessfn(options){
				if (options.shirt_move_left_src) {
					return -.3;
				} else {
					return 0;
				}
			}
		}),
		"upper_belly_split_acc_l": genlayer_clothing_belly_split_acc("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_move_left_src;
			},
			dxfn(options) {
				if (options.shirt_move_left_src) {
					if (options.belly >= 22) {
						return 12;
					} else {
						return 10;
					}
				} else {
					return 0;
				}
			},
			dyfn(options) {
				if (options.shirt_move_left_src) {
					return -4;
				} else {
					return 0;
				}
			},
		}),
		"upper_belly_split_acc_l2": genlayer_clothing_belly_split_acc("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_move_left2_src;
			},
			dxfn(options) {
				if (options.shirt_move_left2_src) {
					if (options.belly >= 22) {
						return 14;
					} else {
						return 12;
					}
				} else {
					return 0;
				}
			},
			dyfn(options) {
				if (options.shirt_move_left2_src) {
					return -2;
				} else {
					return 0;
				}
			},
		}),
		"upper_belly_split_acc_r": genlayer_clothing_belly_split_acc("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_move_right_src;
			}
		}),
		"upper_belly_split_acc_r2": genlayer_clothing_belly_split_acc("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_move_right2_src;
			},
			dxfn(options) {
				if (options.shirt_move_right2_src) {
					return -4;
				}
			},
		}),
		"upper_belly_split_acc_r3": genlayer_clothing_belly_split_acc("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_move_right3_src;
			},
			dxfn(options) {
				if (options.shirt_move_right3_src) {
					return -6;
				}
			},
		}),
		"upper_fitted_left_acc": genlayer_clothing_fitted_left_acc("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_fitted_left_move_src;
			},
			dxfn(options) {
				return -1;
			},
		}),
		"upper_fitted_right_acc": genlayer_clothing_fitted_right_acc("upper", {
			zfn(options) {
				return options.zupper
			},
			masksrcfn(options) {
				return options.shirt_fitted_right_move_src;
			},
			dxfn(options) {
				return 1;
			},
		}),
		"upper_breasts": genlayer_clothing_breasts("upper", {
			zfn(options) {
                if (options.acc_layer_under) {
                    return ZIndices.upper + 1;
                } else {
                    return options.zupper
				}
			},
			masksrcfn(options) {
				return options.shirt_mask_breasts_src;
			}
		}),
		"upper_acc": genlayer_clothing_accessory("upper", {
			zfn(options) {
				if (options.arm_right === "hold" && options.sleeve_over_hold) {
					return ZIndices.lower_high;
				} else {
					return options.zupper;
				}
			},
			masksrcfn(options) {
				if (options.belly >= 19 && options.worn_upper_setup.pregType == "split") {
					return options.shirt_mask_clip_src;
				} else {
					return options.shirt_fitted_clip_src;
				}
			}
		}),
		"upper_breasts_acc": genlayer_clothing_breasts_acc("upper", {
			zfn(options) {
				return options.zupper
			}
		}),
		"upper_rightarm": LJgenlayer_clothing_arm("right", "upper", {
			zfn(options) {
				return options.zupperright
			}
		}),
		"upper_leftarm": LJgenlayer_clothing_arm("left", "upper", {
			zfn(options) {
				return options.zupperleft
			},
			masksrcfn(options) {
				return options.belly_hides_lower ? options.belly_mask_clip_src : null;
			}
		}),
		"upper_rightarm_acc": LJgenlayer_clothing_arm_acc("right", "upper", {
			zfn(options) {
				return options.zupperright
			}
		}),
		"upper_leftarm_acc": LJgenlayer_clothing_arm_acc("left", "upper", {
			zfn(options) {
				return options.zupperleft
			}
		}),
		"upper_back": genlayer_clothing_back_img('upper', {
			z: ZIndices.back_lower
		}),
		/***
		 *     ██████  ██    ██ ███████ ██████  ██    ██ ██████  ██████  ███████ ██████
		 *    ██    ██ ██    ██ ██      ██   ██ ██    ██ ██   ██ ██   ██ ██      ██   ██
		 *    ██    ██ ██    ██ █████   ██████  ██    ██ ██████  ██████  █████   ██████
		 *    ██    ██  ██  ██  ██      ██   ██ ██    ██ ██      ██      ██      ██   ██
		 *     ██████    ████   ███████ ██   ██  ██████  ██      ██      ███████ ██   ██
		 *
		 *
		 */
		"over_upper_main": genlayer_clothing_main('over_upper'),
		"over_upper_breasts": genlayer_clothing_breasts("over_upper"),
		"over_upper_acc": genlayer_clothing_accessory('over_upper'),
		"over_upper_rightarm": LJgenlayer_clothing_arm("right", "over_upper", {
			zfn(options) {
				return (options.arm_right === "bound"  || (options.arm_right === "idle" && !options.LJ_zRarmup )) ? (ZIndices.base - 0.5) : ZIndices.over_upper_arms_cover;//改动：外套手臂
			}
		}),
		"over_upper_leftarm": LJgenlayer_clothing_arm("left", "over_upper", {
			zfn(options) {
				return (options.arm_left === "bound"  || options.arm_left === "idle" ) ? (ZIndices.base - 0.5) : ZIndices.over_upper_arms_cover;//改动：外套手臂
			}
		}),
		/***
		 *     ██████  ███████ ███    ██ ██ ████████  █████  ██      ███████
		 *    ██       ██      ████   ██ ██    ██    ██   ██ ██      ██
		 *    ██   ███ █████   ██ ██  ██ ██    ██    ███████ ██      ███████
		 *    ██    ██ ██      ██  ██ ██ ██    ██    ██   ██ ██           ██
		 *     ██████  ███████ ██   ████ ██    ██    ██   ██ ███████ ███████
		 *
		 *
		 */

		"genitals": genlayer_clothing_main('genitals', {
			srcfn(options) {
				let size = "";
				if (options.worn_genitals_setup.penisSize) {
					switch(options.penis_size) {
						case -2: case -1:
							size = -1;
							break;
						case 0:
							size = 0;
							break;
						case 1: case 2:
							size = 1;
							break;
						case 3: case 4:
							size = 2;
							break;
					}
				}
				return 'img/clothes/genitals/' + options.worn_genitals_setup.variable + '/' + options.worn_genitals_integrity + size + '.png';
			},
			showfn(options) {
				return options.worn_genitals > 0 &&
					options.worn_genitals_setup.mainImage !== 0 &&
					!options.worn_genitals_setup.hideUnderLower.includes(options.worn_under_lower_setup.name) &&
					!options.belly_hides_under_lower;
			},
			zfn(options) {
				if (options.crotch_exposed) {
					return ZIndices.penis_chastity + 0.1;
				}else {
					return ZIndices.penisunderclothes + 0.1;
				}
			}
		}),
		/***
		 *    ██       ██████  ██     ██ ███████ ██████
		 *    ██      ██    ██ ██     ██ ██      ██   ██
		 *    ██      ██    ██ ██  █  ██ █████   ██████
		 *    ██      ██    ██ ██ ███ ██ ██      ██   ██
		 *    ███████  ██████   ███ ███  ███████ ██   ██
		 *
		 *
		 */
		"lower": genlayer_clothing_main('lower', {
			zfn(options) {
				return options.worn_lower_setup.high_img ? ZIndices.lower_high : options.worn_lower_setup.type.includes("covered") ? ZIndices.lower_cover : ZIndices.lower;
			},
			masksrcfn(options) {
				if (between(options.belly, 15, 24)) {
					return options.belly_mask_clip_src;
				} else {
					return options.feet_clip_src;
				}
			},
		}),
		"lower_belly_2": genlayer_clothing_belly_2("lower", {
			masksrcfn(options) {
				return options.belly_mask_src;
			},
			zfn(options) {
				return options.worn_lower_setup.high_img ? ZIndices.lower_high : ZIndices.lower_belly;
			}
		}),
		"lower_belly": genlayer_clothing_belly("lower", {
			masksrcfn(options) {
				return options.belly_mask_src;
			},
			zfn(options) {
				return options.worn_lower_setup.high_img ? ZIndices.lower_high : ZIndices.lower_belly;
			}
		}),
		"lower_belly_shadow": genlayer_clothing_belly_shadow("lower", {
			masksrcfn(options) {
				return options.belly_mask_lower_shadow_src;
			},
			zfn(options) {
				return options.worn_lower_setup.high_img ? ZIndices.lower_high : ZIndices.lower_belly;
			}
		}),
		"lower_belly_acc": genlayer_clothing_belly_acc("lower", {
			masksrcfn(options) {
				return options.belly_mask_src;
			},
			zfn(options) {
				return options.worn_lower_setup.high_img ? ZIndices.lower_high : ZIndices.lower_belly;
			}
		}),
		"lower_acc": genlayer_clothing_accessory("lower", {
			srcfn(options) {
				let path = 'img/clothes/lower/' +
					options.worn_lower_setup.variable + '/' +
					(options.worn_lower_setup.accessory_integrity_img ? 'acc_' + options.worn_lower_integrity : options.worn_upper_setup.name === "school blouse" && ["school pinafore", "plaid school pinafore"].includes(options.worn_lower_setup.name) ? 'acc_under' : 'acc') + '.png';
					return gray_suffix(path, options.filters['worn_lower_acc'])
				},
				zfn(options) {
					return options.worn_lower_setup.high_img ? ZIndices.lower_high : options.worn_lower_setup.type.includes("covered") ? ZIndices.lower_cover : ZIndices.lower;
				},
				masksrcfn(options) {
					if (between(options.belly, 15, 24)) {
						return options.belly_mask_clip_src;
					} else {
						return options.feet_clip_src;
					}
				},
		}),
		"lower_penis": {
			srcfn(options) {
				//ToDo: add images for lower penis bulges. check against pregnancy belly
				let path = 'img/clothes/lower/' + options.worn_lower_setup.variable + '/' + 'penis.png';
				return gray_suffix(path, options.filters['worn_lower'])
			},
			showfn(options) {
				return options.show_clothes &&
					!options.belly_hides_lower &&
					options.worn_lower > 0 &&
					options.worn_lower_setup.penis_img === 1 &&
					calculatePenisBulge() - 6 > 0;
			},
			z: ZIndices.lower_top,
			filters: ["worn_lower"],
			animation: "idle"
		},
		"lower_penis_acc": {
			srcfn(options) {
				//ToDo: add images for lower penis bulges. check against pregnancy belly
				let path = 'img/clothes/lower/' + options.worn_lower_setup.variable + '/' + 'acc_penis.png';
				return gray_suffix(path, options.filters['worn_lower_acc'])
			},
			showfn(options) {
				return options.show_clothes &&
					!options.belly_hides_lower &&
					options.worn_lower > 0 &&
					options.worn_lower_setup.penis_img === 1 &&
					options.worn_lower_setup.accessory === 1 &&
					calculatePenisBulge() - 6 > 0;
			},
			z: ZIndices.lower_top,
			filters: ["worn_lower_acc"],
			animation: "idle"
		},
		"lower_back": genlayer_clothing_back_img('lower', {
			z: ZIndices.back_lower
		}),
		/***
		 *     ██████  ██    ██ ███████ ██████  ██       ██████  ██     ██ ███████ ██████
		 *    ██    ██ ██    ██ ██      ██   ██ ██      ██    ██ ██     ██ ██      ██   ██
		 *    ██    ██ ██    ██ █████   ██████  ██      ██    ██ ██  █  ██ █████   ██████
		 *    ██    ██  ██  ██  ██      ██   ██ ██      ██    ██ ██ ███ ██ ██      ██   ██
		 *     ██████    ████   ███████ ██   ██ ███████  ██████   ███ ███  ███████ ██   ██
		 *
		 *
		 */
		"over_lower": genlayer_clothing_main('over_lower'),
		"over_lower_acc": genlayer_clothing_accessory('over_lower'),
		"over_lower_back": genlayer_clothing_back_img('over_lower'),
		/***
		 *    ██    ██ ███    ██ ██████  ███████ ██████  ██       ██████  ██     ██ ███████ ██████
		 *    ██    ██ ████   ██ ██   ██ ██      ██   ██ ██      ██    ██ ██     ██ ██      ██   ██
		 *    ██    ██ ██ ██  ██ ██   ██ █████   ██████  ██      ██    ██ ██  █  ██ █████   ██████
		 *    ██    ██ ██  ██ ██ ██   ██ ██      ██   ██ ██      ██    ██ ██ ███ ██ ██      ██   ██
		 *     ██████  ██   ████ ██████  ███████ ██   ██ ███████  ██████   ███ ███  ███████ ██   ██
		 *
		 *
		 */
		"under_lower": genlayer_clothing_main('under_lower', {
			zfn(options) {
				return options.worn_lower_setup.high_img ? ZIndices.under_lower_high : ZIndices.under_lower;
			},
			masksrcfn(options) {
				return options.belly_mask_under_clip_src;
			}
		}),
		"under_lower_belly_2": genlayer_clothing_belly_2("under_lower", {
			masksrcfn(options) {
				return options.belly_mask_src;
			},
			zfn(options) {
				return options.worn_lower_setup.high_img ? ZIndices.under_lower_high : ZIndices.under_lower;
			},
			showfn(options) {
				return options.belly > 7
					&& options.show_clothes
					&& !options.belly_hides_under_lower
					&& options.worn_under_lower > 0
					&& options.worn_under_lower_setup.mainImage !== 0
			}
		}),
		"under_lower_belly": genlayer_clothing_belly("under_lower", {
			masksrcfn(options) {
				return options.belly_mask_src;
			},
			zfn(options) {
				return options.worn_lower_setup.high_img ? ZIndices.under_lower_high : ZIndices.under_lower;
			},
			showfn(options) {
				return options.belly > 7
					&& options.show_clothes
					&& !options.belly_hides_under_lower
					&& options.worn_under_lower > 0
					&& options.worn_under_lower_setup.mainImage !== 0
			}
		}),
		"under_lower_belly_shadow": genlayer_clothing_belly_shadow("under_lower", {
			masksrcfn(options) {
				return options.belly_mask_lower_shadow_src;
			},
			zfn(options) {
				return ZIndices.under_lower_top_high;
			},
			showfn(options) {
				return options.belly > 7
					&& options.show_clothes
					&& !options.belly_hides_under_lower
					&& options.worn_under_lower > 0
					&& options.worn_under_lower_setup.mainImage !== 0
			},
		}),
		"under_lower_belly_acc": genlayer_clothing_belly_acc("under_lower", {
			masksrcfn(options) {
				return options.belly_mask_src;
			},
			zfn(options) {
				return options.worn_lower_setup.high_img ? ZIndices.under_lower_high : ZIndices.under_lower;
			},
			showfn(options) {
				return options.belly > 7
					&& options.show_clothes
					&& !options.belly_hides_under_lower
					&& options.worn_under_lower > 0
					&& options.worn_under_lower_setup.accessory === 1
			}
		}),
		"under_lower_acc": genlayer_clothing_accessory('under_lower'),
		"under_lower_penis": {
			srcfn(options) {
				//ToDo: expand the existing bulk images by providing a small bulge when `calculatePenisBulge()` is less than 8 (max is 15). check against pregnancy belly
				let path = 'img/clothes/under_lower/' + options.worn_under_lower_setup.variable + '/' + 'penis.png';
				return gray_suffix(path, options.filters['worn_under_lower'])
			},
			showfn(options) {
				return options.show_clothes &&
					!options.belly_hides_under_lower &&
					options.worn_under_lower > 0 &&
					options.worn_under_lower_setup.penis_img === 1 &&
					calculatePenisBulge() > 0;
			},
			z: ZIndices.under_lower_top,
			filters: ["worn_under_lower"],
			animation: "idle"
		},
		"under_lower_penis_acc": {
			srcfn(options) {
				//ToDo: expand the existing bulk images by providing a small bulge when `calculatePenisBulge()` is less than 8 (max is 15). check against pregnancy belly
				let path = 'img/clothes/under_lower/' + options.worn_under_lower_setup.variable + '/' + 'acc_penis.png';
				return gray_suffix(path, options.filters['worn_under_lower_acc'])
			},
			showfn(options) {
				return options.show_clothes &&
					!options.belly_hides_under_lower &&
					options.worn_under_lower > 0 &&
					options.worn_under_lower_setup.penis_img === 1 &&
					options.worn_under_lower_setup.accessory === 1 &&
					calculatePenisBulge() > 0;
			},
			z: ZIndices.under_lower_top,
			filters: ["worn_under_lower_acc"],
			animation: "idle"
		},
		/***
		 *    ██    ██ ███    ██ ██████  ███████ ██████  ██    ██ ██████  ██████  ███████ ██████
		 *    ██    ██ ████   ██ ██   ██ ██      ██   ██ ██    ██ ██   ██ ██   ██ ██      ██   ██
		 *    ██    ██ ██ ██  ██ ██   ██ █████   ██████  ██    ██ ██████  ██████  █████   ██████
		 *    ██    ██ ██  ██ ██ ██   ██ ██      ██   ██ ██    ██ ██      ██      ██      ██   ██
		 *     ██████  ██   ████ ██████  ███████ ██   ██  ██████  ██      ██      ███████ ██   ██
		 *
		 *
		 */
		"under_upper": genlayer_clothing_main('under_upper', {
			masksrcfn(options) {
				if (options.belly >= 19 && options.worn_upper_setup.pregType == "split") {
					return options.worn_under_upper_setup.pregType === "split" &&
					options.shirt_mask_clip_src;
				} else {
					return options.worn_under_upper_setup.formfitting &&
					options.shirt_fitted_clip_src;
				}
			}
		}),
		"under_upper_fitted_left": genlayer_clothing_fitted_left("under_upper", {
			masksrcfn(options) {
				return options.shirt_fitted_left_move_src;
			},
			dxfn(options) {
				return -1;
			},
		}),
		"under_upper_fitted_right": genlayer_clothing_fitted_right("under_upper", {
			masksrcfn(options) {
				return options.shirt_fitted_right_move_src;
			},
			dxfn(options) {
				return 1;
			},
		}),
		"under_upper_belly_2": genlayer_clothing_belly_2("under_upper", {
			masksrcfn(options) {
				return options.belly_mask_src;
			},
			zfn(options) {
				return ZIndices.under_upper_top;
			}
		}),
		"under_upper_belly": genlayer_clothing_belly("under_upper", {
			masksrcfn(options) {
				return options.belly_mask_src;
			},
			zfn(options) {
				return ZIndices.under_upper_top;
			}
		}),
		/*** Did not work
		"under_upper_belly_shadow": genlayer_clothing_belly_highlight("under_upper", {
			masksrcfn(options) {
				return options.belly_mask_upper_shadow_src;
			},
			zfn(options) {
				return ZIndices.under_upper_top_high;
			}
		}),
		**/
		"under_upper_belly_acc": genlayer_clothing_belly_acc("under_upper", {
			masksrcfn(options) {
				return options.belly_mask_src;
			},
			zfn(options) {
				return options.worn_lower_setup.high_img ? ZIndices.under_upper_top_acc : ZIndices.under_upper_top_acc;
			}
		}),
		"under_upper_breasts": genlayer_clothing_breasts("under_upper"),
		"under_upper_acc": genlayer_clothing_accessory('under_upper'),
		"under_upper_breasts_acc": genlayer_clothing_breasts_acc('under_upper'),
		"under_upper_back": genlayer_clothing_back_img('under_upper'),
		"under_upper_rightarm": LJgenlayer_clothing_arm("right", "under_upper", {
			zfn(options) {
				return (options.arm_right === "bound"  || (options.arm_right === "idle" && !options.LJ_zRarmup )) ?  (ZIndices.base - 1.8) : ZIndices.under_upper_arms_cover;
			}
		}),
		"under_upper_leftarm": LJgenlayer_clothing_arm("left", "under_upper", {
			zfn(options) {
				return (options.arm_left === "bound"  || options.arm_left === "idle" ) ? (ZIndices.base - 1.8) : ZIndices.under_upper_arms_cover;//改动：前置内衣
			}
		}),
		/***
		 *    ██   ██  █████  ███    ██ ██████  ███████
		 *    ██   ██ ██   ██ ████   ██ ██   ██ ██
		 *    ███████ ███████ ██ ██  ██ ██   ██ ███████
		 *    ██   ██ ██   ██ ██  ██ ██ ██   ██      ██
		 *    ██   ██ ██   ██ ██   ████ ██████  ███████
		 *
		 *
		 */
		"hands": genlayer_clothing_main('hands'),
		"hands_left": {
			srcfn(options) {
				let path = 'img/clothes/hands/' +
					options.worn_hands_setup.variable + '/' +
					(options.arm_left === "cover" ? "left_cover" : "left") + (options.arm_left === "bound" ? '_bound':"") + '.png';
				return gray_suffix(path, options.filters['worn_hands']);
			},
			showfn(options) {
				return options.show_clothes &&
					options.worn_hands > 0 &&
					options.worn_hands_setup.leftImage === 1 &&
					options.arm_left !== "none"
			},
			zfn(options) {
				return (options.arm_left === "bound"  || options.arm_left === "idle" )? (ZIndices.base - 1.4): ZIndices.hands;//改动：手衣服调整
			},
			filters: ["worn_hands"],
			animation: "idle"
		},
		"hands_left_acc": {
			srcfn(options) {
				let path = 'img/clothes/hands/' +
					options.worn_hands_setup.variable + '/' +
					(options.arm_left === "cover" ? "left_cover" : "left") + (options.arm_left === "bound" ? '_bound':"") + '_acc.png';
				return gray_suffix(path, options.filters['worn_hands_acc']);
			},
			showfn(options) {
				return options.show_clothes &&
					options.worn_hands > 0 &&
					options.worn_hands_setup.leftImage === 1 &&
					options.worn_hands_setup.accessory === 1 &&
					options.arm_left !== "none"
			},
			zfn(options) {
				return (options.arm_left === "bound"  || options.arm_left === "idle")? (ZIndices.base - 1.4): ZIndices.hands;//改动：手衣服调整
			},
			filters: ["worn_hands_acc"],
			animation: "idle"
		},
		"hands_right": {
			srcfn(options) {
				let path = 'img/clothes/hands/' +
					options.worn_hands_setup.variable + '/' +
					(options.arm_right === "cover" ? "right_cover" : options.handheld_position ? "hold" : "right") + (options.arm_right === "bound" ? '_bound':"") + '.png';
				return gray_suffix(path, options.filters['worn_hands']);
			},
			showfn(options) {
				return options.show_clothes &&
					options.worn_hands > 0 &&
					options.worn_hands_setup.rightImage === 1 &&
					options.arm_right !== "none"
			},
			zfn(options) {
				return (options.arm_right === "bound"  || (options.arm_right === "idle" && !options.LJ_zRarmup )) ?  (ZIndices.base - 1.4) : ZIndices.hands;//改动：手衣服调整
			},
			filters: ["worn_hands"],
			animation: "idle"
		},
		"hands_right_acc": {
			srcfn(options) {
				let path = 'img/clothes/hands/' +
					options.worn_hands_setup.variable + '/' +
					(options.arm_right === "cover" ? "right_cover" : options.handheld_position ? "hold" : "right") + (options.arm_right === "bound" ? '_bound':"")+ '_acc.png';
				return gray_suffix(path, options.filters['worn_hands_acc']);
			},
			showfn(options) {
				return options.show_clothes &&
					options.worn_hands > 0 &&
					options.worn_hands_setup.rightImage === 1 &&
					options.worn_hands_setup.accessory === 1 &&
					options.arm_right !== "none"
			},
			zfn(options) {
				return (options.arm_right === "bound"  || (options.arm_right === "idle" && !options.LJ_zRarmup )) ?  (ZIndices.base - 1.4) : ZIndices.hands;//改动：手衣服调整
			},
			filters: ["worn_hands_acc"],
			animation: "idle"
		},
		/***
		 *    ██   ██  █████  ███    ██ ██████  ██   ██ ██████ ██     ██████
		 *    ██   ██ ██   ██ ████   ██ ██   ██ ██   ██ ██     ██     ██   ██
		 *    ███████ ███████ ██ ██  ██ ██   ██ ███████ ██████ ██     ██   ██
		 *    ██   ██ ██   ██ ██  ██ ██ ██   ██ ██   ██ ██     ██     ██   ██
		 *    ██   ██ ██   ██ ██   ████ ██████  ██   ██ ██████ ██████ ██████
		 *
		 *
		 */
		"handheld": genlayer_clothing_main('handheld', {
			srcfn(options) {
				let torchLevels = [100, 80, 60, 40, 20, 1, 0];
				let fileFormat = options.worn_handheld_setup.name === "torch" && V.catacombs_torch >= 0 ? `${torchLevels.findIndex(x => V.catacombs_torch >= x) + 1}.png` : ".png";
				let path = 'img/clothes/handheld/' +
					options.worn_handheld_setup.variable + '/' +
					(options.arm_right === "cover" ? "right_cover" : "right") +	fileFormat;
				return gray_suffix(path, options.filters['worn_handheld']);
			},
			showfn(options) {
				if (options.arm_right === "cover") {
					return options.show_clothes &&
					options.worn_handheld > 0 &&
					options.worn_handheld_setup.coverImage !== 0;
				} else {
					return options.show_clothes &&
					options.worn_handheld > 0 &&
					options.arm_right !== "none"&&
					options.arm_right !== "bound";
				}
			},
			zfn(options) {
				return options.handheld_overhead || options.worn_handheld_setup.type.includes("prop") ? ZIndices.over_upper : ZIndices.handheld;
			},
		}),
		"handheld_acc": genlayer_clothing_accessory('handheld', {
			srcfn(options) {
				let path = 'img/clothes/handheld/' +
					options.worn_handheld_setup.variable + '/' +
					(options.arm_right === "cover" ? "right_cover" : "right") + '_acc.png';
				return gray_suffix(path, options.filters['worn_handheld_acc']);
			},
			showfn(options) {
				if (options.arm_right === "cover") {
					return options.show_clothes &&
					options.worn_handheld > 0 &&
					options.worn_handheld_setup.accessory === 1 &&
					options.worn_handheld_setup.coverImage !== 0;
				} else {
					return options.show_clothes &&
					options.worn_handheld > 0 &&
					options.worn_handheld_setup.accessory === 1 &&
					options.arm_right !== "none"&&
					options.arm_right !== "bound";
				}
			},
			zfn(options) {
				return options.handheld_overhead || options.worn_handheld_setup.type.includes("prop") ? ZIndices.over_upper : ZIndices.handheld;
			},
		}),
		"handheld_left": {
			srcfn(options) {
				let path = 'img/clothes/handheld/' +
					options.worn_handheld_setup.variable + '/' +
					(options.arm_left === "cover" ? "left_cover" : "left") + '.png';
				return gray_suffix(path, options.filters['worn_handheld']);
			},
			showfn(options) {
				return options.show_clothes &&
					options.worn_handheld > 0 &&
					options.worn_handheld_setup.leftImage === 1 &&
					options.arm_left !== "none"&&
					options.arm_left !== "bound";
			},
			zfn(options) {
				return options.arm_left === "cover" ? ZIndices.hands :  (ZIndices.base - 1.4);
			},
			filtersfn(options) {
				return ["worn_handheld"];
			},
		},
		"handheld_left_acc": {
			srcfn(options) {
				let path = 'img/clothes/handheld/' +
					options.worn_handheld_setup.variable + '/' +
					(options.arm_left === "cover" ? "left_cover" : "left") + '_acc.png';
				return gray_suffix(path, options.filters['worn_handheld_acc']);
			},
			showfn(options) {
				return options.show_clothes &&
					options.worn_handheld > 0 &&
					options.worn_handheld_setup.leftImage === 1 &&
					options.worn_handheld_setup.accessory === 1 &&
					options.arm_left !== "none"&&
					options.arm_left !== "bound";
			},
			zfn(options) {
				return options.arm_left === "cover" ? ZIndices.hands :  (ZIndices.base - 1.4);
			},
			filtersfn(options) {
				return ["worn_handheld_acc"]
			},
		},
		"handheld_back": LJgenlayer_clothing_back_img('handheld',{
			z: ZIndices.over_head_back
		}),
		"handheld_back_acc": genlayer_clothing_back_img_acc('handheld', {
			z: ZIndices.over_head_back
		}),
		/***
		 *    ██   ██ ███████  █████  ██████
		 *    ██   ██ ██      ██   ██ ██   ██
		 *    ███████ █████   ███████ ██   ██
		 *    ██   ██ ██      ██   ██ ██   ██
		 *    ██   ██ ███████ ██   ██ ██████
		 *
		 *
		 */
		"head": genlayer_clothing_main('head', {
			srcfn(options) {
				let path = 'img/clothes/head/' +
					options.worn_head_setup.variable + '/' +
					(options.hood_damage ? options.worn_upper_integrity : options.worn_head_integrity) + '.png';
				return gray_suffix(path, options.filters['worn_head']);
			},
			masksrcfn(options) {
				if (options.worn_upper_setup.name === "cocoon") {
					return options.head_mask_src;
				} else {
					return "";
				}
			},
		}),
		"head_acc": genlayer_clothing_accessory('head', {
			srcfn(options) {
				let path = 'img/clothes/head/' +
					options.worn_head_setup.variable + '/' +
					(options.hood_damage ? 'acc_' + options.worn_upper_integrity : 'acc') + '.png';
				return gray_suffix(path, options.filters['worn_head_acc']);
			},
		}),
		"head_back_acc": genlayer_clothing_back_img_acc('head'),
		"head_back": genlayer_clothing_back_img('head'),
		/***
		 *     ██████  ██    ██ ███████ ██████          ██   ██ ███████  █████  ██████
		 *    ██    ██ ██    ██ ██      ██   ██         ██   ██ ██      ██   ██ ██   ██
		 *    ██    ██ ██    ██ █████   ██████          ███████ █████   ███████ ██   ██
		 *    ██    ██  ██  ██  ██      ██   ██         ██   ██ ██      ██   ██ ██   ██
		 *     ██████    ████   ███████ ██   ██ ███████ ██   ██ ███████ ██   ██ ██████
		 *
		 *
		 */
		"over_head": genlayer_clothing_main('over_head'),
		"over_head_acc": genlayer_clothing_accessory('over_head'),
		"over_head_back_acc": genlayer_clothing_back_img_acc('over_head'),
		"over_head_back": genlayer_clothing_back_img('over_head'),
		/***
		 *    ███████  █████   ██████ ███████
		 *    ██      ██   ██ ██      ██
		 *    █████   ███████ ██      █████
		 *    ██      ██   ██ ██      ██
		 *    ██      ██   ██  ██████ ███████
		 *
		 *
		 */

		"face": genlayer_clothing_main('face', {
			srcfn(options) {
				let isAltPosition = options.alt_position_face &&
				options.worn_face_setup.altposition !== undefined;
				let path = 'img/clothes/face/' +
					options.worn_face_setup.variable + '/' +
					options.worn_face_integrity + (isAltPosition ? '_alt' : '') + '.png';
				return gray_suffix(path, options.filters['worn_face']);
			},
			zfn(options) {
				let isAltPosition = options.alt_position_face &&
				options.worn_face_setup.altposition !== undefined;
				if (isAltPosition && options.worn_face_setup.type.includes("cool") || options.worn_face_setup.type.includes("glasses")) {
					return ZIndices.over_head;
				} else if (options.facewear_layer === "front") {
					return ZIndices.face - 12.5;
				} else {
					return ZIndices.face;
				}
			},
		}),
		"face_acc": genlayer_clothing_accessory('face', {
			srcfn(options) {
				let isAltPosition = options.alt_position_face &&
				options.worn_face_setup.altposition !== undefined;
				let path = 'img/clothes/face/' +
				options.worn_face_setup.variable + '/' +
				'acc' +
				(setup.accessory_integrity_img ? '_' + options.worn_face_integrity : '') +
				(isAltPosition ? '_alt' : '') + '.png';
				return gray_suffix(path, options.filters['worn_face_acc']);
			},
			zfn(options) {
				let isAltPosition = options.alt_position_face &&
				options.worn_face_setup.altposition !== undefined;
				if (isAltPosition && options.worn_face_setup.type.includes("cool") || options.worn_face_setup.type.includes("glasses")) {
					return ZIndices.over_head;
				} else if (options.facewear_layer === "front") {
					return ZIndices.face - 12.5;
				} else {
					return ZIndices.face;
				}
			},
		}),
		"face_back_acc": genlayer_clothing_back_img_acc('face'),
		"face_back": genlayer_clothing_back_img('face'),

		/***
		 *    ███    ██ ███████  ██████ ██   ██
		 *    ████   ██ ██      ██      ██  ██
		 *    ██ ██  ██ █████   ██      █████
		 *    ██  ██ ██ ██      ██      ██  ██
		 *    ██   ████ ███████  ██████ ██   ██
		 *
		 *
		 */
		"neck": genlayer_clothing_main('neck', {
			srcfn(options) {
				let isAltPosition = options.alt_position_neck &&
				options.worn_neck_setup.altposition !== undefined;
				let path = 'img/clothes/neck/' +
					options.worn_neck_setup.variable + '/' +
					options.worn_neck_integrity + (options.nocollar ? '_nocollar' : options.serafuku ? '_serafuku' :'') +  (isAltPosition ? '_alt' : '') + '.png';
				return gray_suffix(path, options.filters['worn_neck']);
			},
			masksrcfn(options) {
				return options.high_waist_suspenders ? "img/clothes/neck/suspenders/mask.png" : null;
			},
			zfn(options) {
				return options.hood_mask ? ZIndices.collar : ZIndices.neck;
			},
		}),
		"neck_acc": genlayer_clothing_accessory('neck', {
			srcfn(options) {
				let isAltPosition = options.alt_position_neck &&
				options.worn_neck_setup.altposition !== undefined;
				let path = 'img/clothes/neck/' +
				options.worn_neck_setup.variable + '/' +
				'acc' +
				(setup.accessory_integrity_img ? '_' + options.worn_neck_integrity : '') +
				(isAltPosition ? '_alt' : '') + '.png';
				return gray_suffix(path, options.filters['worn_neck_acc']);
			},
			zfn(options) {
				return (options.worn_head_setup.mask_img === 1 &&
				!(options.hood_down && options.worn_head_setup.hood && options.worn_head_setup.outfitSecondary !== undefined))
				? ZIndices.collar : ZIndices.neck;
			},
			dyfn(options) {
				return options.high_waist_suspenders ? -8 : 0;
			}
		}),
		/***
		 *    ██      ███████  ██████  ███████
		 *    ██      ██      ██       ██
		 *    ██      █████   ██   ███ ███████
		 *    ██      ██      ██    ██      ██
		 *    ███████ ███████  ██████  ███████
		 *
		 *
		 */
		"legs": genlayer_clothing_main('legs', {
			masksrcfn(options) {
				if (between(options.belly, 15, 24)) {
					return options.belly_mask_clip_src;
				} else {
					return options.feet_clip_src;
				}
			},
			zfn(options) {
				if (options.worn_under_lower_setup.set === options.worn_under_upper_setup.set ||
					options.worn_under_lower_setup.high_img === 1) {
					return ZIndices.legs;
				} else {
					return ZIndices.legs_high;
				}
			}
		}),
		"legs_acc": genlayer_clothing_accessory('legs', {
			masksrcfn(options) {
				if (between(options.belly, 15, 24)) {
					return options.belly_mask_clip_src;
				} else {
					return options.feet_clip_src;
				}
			},
			zfn(options) {
				if (options.worn_under_lower_setup.set === options.worn_under_upper_setup.set ||
					options.worn_under_lower_setup.high_img === 1) {
					return ZIndices.legs;
				} else {
					return ZIndices.legs_high;
				}
			}
		}),
		"legs_back_acc": genlayer_clothing_back_img_acc('legs'),
		"legs_back": genlayer_clothing_back_img('legs'),
		/***
		 *    ███████ ███████ ███████ ████████
		 *    ██      ██      ██         ██
		 *    █████   █████   █████      ██
		 *    ██      ██      ██         ██
		 *    ██      ███████ ███████    ██
		 *
		 *
		 */
		"feet": genlayer_clothing_main('feet', {
			zfn(options) {
				if (options.lower_tucked && !options.worn_lower_setup.notuck && !options.worn_feet_setup.notuck) {
					return ZIndices.lower_tucked_feet;
				} else {
					return ZIndices.feet;
				}
			}
		}),
		"feet_acc": genlayer_clothing_accessory('feet', {
			zfn(options) {
				if (options.lower_tucked) {
					return ZIndices.lower_tucked_feet;
				} else {
					return ZIndices.feet;
				}
			}
		}),
		"feet_back_acc": genlayer_clothing_back_img_acc('feet'),
		"feet_back": genlayer_clothing_back_img('feet'),

		// new layer template
		/*
		"": {
			srcfn(options) {
				return ""
			},
			z: ZIndices.,
			animation: "idle"
		},
		*/
	}
}
function LJgenlayer_clothing_back_img(slot, overrideOptions) {
	return Object.assign({
		srcfn(options) {
			let isAltPosition = options.alt_position &&
			options["worn_" + slot + "_setup"].altposition !== undefined;
			let setup = options["worn_" + slot + "_setup"];
			let path = 'img/clothes/' +
				slot + '/' +
				options["worn_" + slot + "_setup"].variable + '/' +
				(isAltPosition ? 'back_alt' : 'back') +
				(setup.back_integrity_img ? '_' + options["worn_" + slot + "_integrity"] : '') + '.png';
			return gray_suffix(path, options.filters[this.filtersfn(options)[0]]);
		},
		showfn(options) {
			if (!options.show_clothes || (slot === "handheld" && ["none", "bound","cover"].includes(options.arm_right) && options.worn_handheld_setup.coverBackImage === 0)) return false;
			let isHoodDown = options.hood_down &&
				options["worn_" + slot + "_setup"].hood &&
				options["worn_" + slot + "_setup"].outfitSecondary !== undefined;
			return options["worn_" + slot] > 0 && options["worn_" + slot + "_setup"].back_img === 1 && !isHoodDown;
		},
		alphafn(options) {
			return options["worn_" + slot + "_alpha"]
		},
		z: ZIndices['over_head_back'],
		filtersfn(options) {
			switch (options["worn_" + slot + "_setup"].back_img_colour) {
				case "none":
					return [];
				case "":
				case undefined:
				case "primary":
					return ["worn_" + slot];
				case "secondary":
					return ["worn_" + slot + "_acc"]
			}
		},
		animation: "idle"
	}, overrideOptions)
}
function LJgenlayer_clothing_arm(arm, slot, overrideOptions) {
	return Object.assign({
		srcfn(options) {
			let isAltPosition = (options.alt_position &&
			options["worn_" + slot + "_setup"].altposition !== undefined &&
			!options.alt_without_sleeves);
			let isAltSleeve = options.alt_sleeve &&
			options.alt_sleeve_state &&
			options["worn_" + slot + "_setup"].altsleeve !== undefined;
			let path = 'img/clothes/' +
				slot + '/' +
				options["worn_" + slot + "_setup"].variable + '/' + 
				(options["arm_" + arm] === "cover" ? (arm + '_cover') :  options.handheld_position && arm === "right" ? "hold" : (arm)) + (options["arm_" + arm] === "bound" ? '_bound':"") +
				(isAltPosition ? "_alt" : "") +
				(isAltSleeve ? "_rolled.png" : ".png");
			return gray_suffix(path, options.filters[this.filtersfn(options)[0]]);
		},
		showfn(options) {
			return options.show_clothes &&
				options["worn_" + slot] > 0 &&
				options["worn_" + slot + "_setup"].sleeve_img === 1 &&
				options["arm_" + arm] !== "none"
		},
		alphafn(options) {
			return options["worn_" + slot + "_alpha"]
		},
		filtersfn(options) {
			switch (options["worn_" + slot + "_setup"].sleeve_colour) {
				case undefined:
				case "":
				case "primary":
					return ["worn_" + slot];
				case "secondary":
					return ["worn_" + slot + "_acc"];
				case "no":
				default:
					return [];
			}
		},
		animation: "idle"
	}, overrideOptions)
}
function LJgenlayer_clothing_arm_acc(arm, slot, overrideOptions) {
	return Object.assign({
		srcfn(options) {
			let path = 'img/clothes/' +
				slot + '/' +
				options["worn_" + slot + "_setup"].variable + '/' + 
				(options["arm_" + arm] === "bound" ?(arm + "_bound_acc.png"):(options["arm_" + arm] === "cover" ? (arm + '_cover_acc.png') : options.handheld_position && arm === "right" ? "hold_acc.png" :(arm + "_acc.png")));
			return gray_suffix(path, options.filters[this.filtersfn(options)[0]]);
		},
		showfn(options) {
			return options.show_clothes &&
				options["worn_" + slot] > 0 &&
				options["worn_" + slot + "_setup"].sleeve_img === 1 &&
				options["worn_" + slot + "_setup"].sleeve_acc_img === 1 &&
				options["arm_" + arm] !== "none"
		},
		alphafn(options) {
			return options["worn_" + slot + "_alpha"]
		},
		filtersfn(options) {
			switch (options["worn_" + slot + "_setup"].accessory_colour_sidebar) {
				case undefined:
				case "":
				case "primary":
					return ["worn_" + slot];
				case "secondary":
					return ["worn_" + slot + "_acc"];
				case "no":
				default:
					return [];
			}
		},
		animation: "idle"
	}, overrideOptions)
}